import numpy as np


class DistanceMetrics:
    """
    Episode-level distance / formation metrics:
      - ally_dispersion_mean: mean pairwise distance among alive allies (off-diagonal)
      - ally_minsep_mean: minimum pairwise distance among alive allies
      - ally_radius_mean: mean distance from alive allies to their centroid

    Call:
      reset() at episode start
      step(ally_pos, ally_alive) each env step
      summary() at episode end
    """

    def __init__(self, n_agents: int, eps: float = 1e-12):
        self.n_agents = int(n_agents)
        self.eps = float(eps)
        self.reset()

    def reset(self):
        self.disp_sum = 0.0
        self.minsep_sum = 0.0
        self.radius_sum = 0.0
        self.steps = 0

    @staticmethod
    def _pairwise_metrics(P: np.ndarray):
        """
        P: [n,2] positions of alive allies
        Returns: dispersion_mean, minsep
        """
        n = P.shape[0]
        if n < 2:
            return 0.0, 0.0

        diff = P[:, None, :] - P[None, :, :]          # [n,n,2]
        D = np.sqrt((diff ** 2).sum(-1))              # [n,n]
        # ignore diagonal by setting to +inf
        np.fill_diagonal(D, np.inf)

        # dispersion: mean of off-diagonal finite distances
        finite = np.isfinite(D)
        disp = float(D[finite].mean()) if finite.any() else 0.0
        minsep = float(D.min()) if finite.any() else 0.0
        return disp, minsep

    @staticmethod
    def _radius_metric(P: np.ndarray):
        """
        P: [n,2] positions of alive allies
        Returns: mean distance to centroid
        """
        n = P.shape[0]
        if n < 1:
            return 0.0
        center = P.mean(axis=0)
        r = np.sqrt(((P - center) ** 2).sum(-1)).mean()
        return float(r)

    def step(self, ally_pos, ally_alive):
        """
        ally_pos: array-like [n_agents,2]
        ally_alive: array-like [n_agents] bool/int
        """
        if ally_pos is None or ally_alive is None:
            return

        P = np.asarray(ally_pos, dtype=np.float32)
        alive = np.asarray(ally_alive).astype(bool)

        if P.ndim != 2 or P.shape[0] != self.n_agents or P.shape[1] != 2:
            # shape mismatch -> skip (better than crashing)
            return

        n_alive = int(alive.sum())
        if n_alive <= 0:
            disp = minsep = radius = 0.0
        else:
            Pa = P[alive]
            disp, minsep = self._pairwise_metrics(Pa)
            radius = self._radius_metric(Pa)

        self.disp_sum += disp
        self.minsep_sum += minsep
        self.radius_sum += radius
        self.steps += 1

    def summary(self):
        if self.steps <= 0:
            return {
                "ally_dispersion_mean": 0.0,
                "ally_minsep_mean": 0.0,
                "ally_radius_mean": 0.0,
            }
        return {
            "ally_dispersion_mean": self.disp_sum / self.steps,
            "ally_minsep_mean": self.minsep_sum / self.steps,
            "ally_radius_mean": self.radius_sum / self.steps,
        }
