# src/utils/trigger_metrics.py
import math
import torch as th


class TriggerMetrics:
    def __init__(self, n_agents, n_enemies, n_actions_total, move_action_ids=None):
        self.n_agents = n_agents
        self.n_enemies = n_enemies
        self.n_actions_total = n_actions_total
        self.n_actions_no_attack = n_actions_total - n_enemies

        # SMAC里 move 常见是 2~5 或 1~4（不同版本会变）
        # 最好从 env 里给进来；没有就先默认一个常见集合
        self.move_action_ids = set(move_action_ids or [2, 3, 4, 5])

        self.reset()

    def reset(self):
        self.t = 0

        self.focus_max_sum = 0.0
        self.entropy_sum = 0.0
        self.attack_steps = 0

        self.kite_count = 0
        self.kite_steps = 0
        self._prev_actions = None

        # trigger相关
        self.trigger_rate_sum = 0.0

        # trigger分桶(0, 1/3, 2/3, 1)
        self.bucket_cnt = [0, 0, 0, 0]
        self.bucket_focus_sum = [0.0, 0.0, 0.0, 0.0]
        self.bucket_entropy_sum = [0.0, 0.0, 0.0, 0.0]
        self.bucket_reward_sum = [0.0, 0.0, 0.0, 0.0]

        # distance metrics
        self.dispersion_sum = 0.0
        self.radius_sum = 0.0
        self.minsep_sum = 0.0
        self.dist_steps = 0

    def _bucket_id(self, T):
        # T in [0,1]
        if T <= 0.0:
            return 0
        if T <= 1 / 3:
            return 1
        if T <= 2 / 3:
            return 2
        return 3

    def _decode_targets(self, actions_1d):
        # actions_1d: [n_agents] python list or tensor
        targets = [-1] * self.n_agents
        for i, a in enumerate(actions_1d):
            a = int(a)
            if a >= self.n_actions_no_attack:
                targets[i] = a - self.n_actions_no_attack  # 0..E-1
        return targets

    def step(self, actions, reward, triggers=None, ally_pos=None):
        """
        actions: Tensor or list, shape [n_agents] or [1,n_agents,1] etc.
        reward: float
        triggers: Tensor shape [n_agents] or [n_agents,1] or [1,n_agents,1]
        ally_pos: Tensor [A,2] or [1,A,2] or [bs,A,2] or list
        """
        # ---- normalize actions to [n_agents] ----
        if isinstance(actions, th.Tensor):
            a = actions
            if a.dim() == 3:  # [bs, A, 1]
                a = a[0, :, 0]
            elif a.dim() == 2:  # [A,1] or [bs,A]
                a = a[:, 0] if a.size(-1) == 1 else a[0]
            actions_1d = a.detach().cpu().tolist()
        else:
            actions_1d = list(actions)

        # ---- focus / entropy ----
        targets = self._decode_targets(actions_1d)
        counts = [0] * self.n_enemies
        atk_n = 0
        for tg in targets:
            if tg >= 0:
                counts[tg] += 1
                atk_n += 1

        ent_this_step = None
        if atk_n > 0:
            self.attack_steps += 1
            focus_max = max(counts)
            self.focus_max_sum += float(focus_max)

            # entropy
            ent = 0.0
            for c in counts:
                if c > 0:
                    p = c / atk_n
                    ent -= p * math.log(p + 1e-12)
            # optional normalize by log(E)
            if self.n_enemies > 1:
                ent /= math.log(self.n_enemies)
            self.entropy_sum += float(ent)
            ent_this_step = float(ent)

        # ---- kiting proxy (attack->move) ----
        if self._prev_actions is not None:
            for i in range(self.n_agents):
                prev = int(self._prev_actions[i])
                curr = int(actions_1d[i])
                prev_is_attack = prev >= self.n_actions_no_attack
                curr_is_move = curr in self.move_action_ids
                if prev_is_attack and curr_is_move:
                    self.kite_count += 1
            self.kite_steps += 1
        self._prev_actions = actions_1d

        # ---- trigger rate & trigger buckets ----
        T = None
        if triggers is not None:
            if isinstance(triggers, th.Tensor):
                tr = triggers
                if tr.dim() == 3:
                    tr = tr[0, :, 0]
                elif tr.dim() == 2 and tr.size(-1) == 1:
                    tr = tr[:, 0]
                T = float(tr.float().mean().item())
            else:
                T = sum(float(x) for x in triggers) / len(triggers)
            self.trigger_rate_sum += T

        # bucket统计：如果没 triggers，就按 bucket0 统计
        b = self._bucket_id(T if T is not None else 0.0)
        self.bucket_cnt[b] += 1
        if atk_n > 0:
            self.bucket_focus_sum[b] += float(max(counts))
            self.bucket_entropy_sum[b] += float(ent_this_step if ent_this_step is not None else 0.0)
        self.bucket_reward_sum[b] += float(reward)

        # ---- distance metrics (ally_pos) ----
        if ally_pos is not None:
            if isinstance(ally_pos, th.Tensor):
                p = ally_pos
                if p.dim() == 3:  # [bs,A,2]
                    p = p[0]
                p = p.float().detach()
            else:
                p = th.tensor(ally_pos, dtype=th.float32)

            A = p.size(0)
            if A >= 2:
                diff = p.unsqueeze(1) - p.unsqueeze(0)  # [A,A,2]
                dist = th.sqrt((diff ** 2).sum(-1) + 1e-12)  # [A,A]
                triu = dist[th.triu_indices(A, A, offset=1).unbind()]
                dispersion = triu.mean().item()
                minsep = triu.min().item()
            else:
                dispersion = 0.0
                minsep = 0.0

            c = p.mean(dim=0, keepdim=True)  # [1,2]
            radius = th.sqrt(((p - c) ** 2).sum(-1) + 1e-12).mean().item()

            self.dispersion_sum += float(dispersion)
            self.radius_sum += float(radius)
            self.minsep_sum += float(minsep)
            self.dist_steps += 1

        self.t += 1

    def summary(self):
        out = {}
        out["focus_max_mean"] = self.focus_max_sum / max(1, self.attack_steps)
        out["target_entropy_mean"] = self.entropy_sum / max(1, self.attack_steps)
        out["kite_per_step"] = self.kite_count / max(1, self.kite_steps)
        out["trigger_rate"] = self.trigger_rate_sum / max(1, self.t)

        for i in range(4):
            cnt = max(1, self.bucket_cnt[i])
            out[f"bucket{i}_cnt"] = self.bucket_cnt[i]
            out[f"bucket{i}_focus_mean"] = self.bucket_focus_sum[i] / cnt
            out[f"bucket{i}_entropy_mean"] = self.bucket_entropy_sum[i] / cnt
            out[f"bucket{i}_reward_mean"] = self.bucket_reward_sum[i] / cnt

        # distance metrics should be outside the bucket loop
        out["ally_dispersion_mean"] = self.dispersion_sum / max(1, self.dist_steps)
        out["ally_radius_mean"] = self.radius_sum / max(1, self.dist_steps)
        out["ally_minsep_mean"] = self.minsep_sum / max(1, self.dist_steps)

        return out
