# src/controllers/trigger_comm_controller.py
from modules.agents import REGISTRY as agent_REGISTRY
from components.action_selectors import REGISTRY as action_REGISTRY
import torch as th

from modules.comm.trigger_net import TriggerNet


class TriggerCommMAC:
    """
    QMIX-style MAC + TriggerNet-based comm trigger.
    - agent 输出 Q
    - trigger_net 基于 agent hidden h + ally_grid 产生 triggers: [bs, A, 1]
    - runner 可通过 get_last_extra() 获取最近一步 triggers（用于写入 batch / 统计）
    """
    def __init__(self, scheme, groups, args):
        self.n_agents = args.n_agents
        self.args = args

        input_shape = self._get_input_shape(scheme)
        self._build_agents(input_shape)

        self.agent_output_type = args.agent_output_type
        self.action_selector = action_REGISTRY[args.action_selector](args)

        self.hidden_states = None

        # ----- TriggerNet -----
        self.h_dim = getattr(args, "h_dim", getattr(args, "rnn_hidden_dim", 64))
        self.trigger_hidden = getattr(args, "trigger_hidden", 64)
        self.trigger_hard = getattr(args, "trigger_hard", True)

        # grid config
        self.use_ally_grid = bool(getattr(args, "use_ally_grid", True))
        self.grid_feat_dim = int(getattr(args, "grid_feat_dim", 64))
        self.grid_radius = int(getattr(args, "ally_grid_radius", 15))
        self.grid_size = 2 * self.grid_radius + 1  # 31 if radius=15

        self.trigger_net = TriggerNet(
            h_dim=self.h_dim,
            hidden_dim=self.trigger_hidden,
            hard=self.trigger_hard,
            use_ally_grid=self.use_ally_grid,
            grid_feat_dim=self.grid_feat_dim,
        )

        self._last_triggers = None  # [bs, A, 1]
        self._last_extra = None     # dict

    def select_actions(self, ep_batch, t_ep, t_env, bs=slice(None), test_mode=False):
        avail_actions = ep_batch["avail_actions"][:, t_ep]
        agent_outputs = self.forward(ep_batch, t_ep, test_mode=test_mode)
        chosen_actions = self.action_selector.select_action(
            agent_outputs[bs], avail_actions[bs], t_env, test_mode=test_mode
        )
        return chosen_actions

    def forward(self, ep_batch, t, test_mode=False):
        agent_inputs = self._build_inputs(ep_batch, t)
        avail_actions = ep_batch["avail_actions"][:, t]

        # agent_outs: [bs*A, n_actions], hidden_states: [bs, A, h_dim]
        agent_outs, self.hidden_states = self.agent(agent_inputs, self.hidden_states)

        bs = ep_batch.batch_size
        h = self.hidden_states.view(bs, self.n_agents, -1)  # [bs, A, h_dim]

        # --------- pass ally_grid to TriggerNet (FIX) ----------
        ally_grid = None
        if self.use_ally_grid:
            if "ally_grid" in ep_batch.data.transition_data:
                ally_grid = ep_batch["ally_grid"][:, t]  # [bs, A, 1, H, W]
            else:
                # fallback: if scheme not ready, still feed zeros so dims match
                ally_grid = th.zeros(
                    (bs, self.n_agents, 1, self.grid_size, self.grid_size),
                    device=h.device,
                    dtype=h.dtype,
                )

        triggers = self.trigger_net(h, ally_grid=ally_grid, test_mode=test_mode)  # [bs, A, 1]
        self._last_triggers = triggers
        self._last_extra = {"triggers": triggers}

        # Q-values masking (same as BasicMAC)
        if self.agent_output_type == "pi_logits":
            if getattr(self.args, "mask_before_softmax", True):
                reshaped_avail_actions = avail_actions.reshape(bs * self.n_agents, -1)
                agent_outs[reshaped_avail_actions == 0] = -1e10
            agent_outs = th.nn.functional.softmax(agent_outs, dim=-1)
            if not test_mode:
                epsilon_action_num = agent_outs.size(-1)
                if getattr(self.args, "mask_before_softmax", True):
                    epsilon_action_num = reshaped_avail_actions.sum(dim=1, keepdim=True).float()
                agent_outs = ((1 - self.action_selector.epsilon) * agent_outs
                              + th.ones_like(agent_outs) * self.action_selector.epsilon / epsilon_action_num)
                if getattr(self.args, "mask_before_softmax", True):
                    agent_outs[reshaped_avail_actions == 0] = 0.0

        return agent_outs.view(bs, self.n_agents, -1)

    # --- runner will use this ---
    def get_last_extra(self):
        return self._last_extra

    def get_last_triggers(self):
        return self._last_triggers

    def init_hidden(self, batch_size):
        self.hidden_states = self.agent.init_hidden().unsqueeze(0).expand(batch_size, self.n_agents, -1)

    def parameters(self):
        # include trigger_net params
        return list(self.agent.parameters()) + list(self.trigger_net.parameters())

    def load_state(self, other_mac):
        self.agent.load_state_dict(other_mac.agent.state_dict())
        if hasattr(other_mac, "trigger_net"):
            self.trigger_net.load_state_dict(other_mac.trigger_net.state_dict())

    def cuda(self):
        self.agent.cuda()
        self.trigger_net.cuda()

    def save_models(self, path):
        th.save(self.agent.state_dict(), "{}/agent.th".format(path))
        th.save(self.trigger_net.state_dict(), "{}/trigger_net.th".format(path))

    def load_models(self, path):
        self.agent.load_state_dict(th.load("{}/agent.th".format(path), map_location=lambda storage, loc: storage))
        try:
            self.trigger_net.load_state_dict(th.load("{}/trigger_net.th".format(path), map_location=lambda storage, loc: storage))
        except FileNotFoundError:
            pass

    def _build_agents(self, input_shape):
        self.agent = agent_REGISTRY[self.args.agent](input_shape, self.args)

    def _build_inputs(self, batch, t):
        bs = batch.batch_size
        inputs = [batch["obs"][:, t]]
        if self.args.obs_last_action:
            if t == 0:
                inputs.append(th.zeros_like(batch["actions_onehot"][:, t]))
            else:
                inputs.append(batch["actions_onehot"][:, t - 1])
        if self.args.obs_agent_id:
            inputs.append(th.eye(self.n_agents, device=batch.device).unsqueeze(0).expand(bs, -1, -1))

        inputs = th.cat([x.reshape(bs * self.n_agents, -1) for x in inputs], dim=1)
        return inputs

    def _get_input_shape(self, scheme):
        input_shape = scheme["obs"]["vshape"]
        if self.args.obs_last_action:
            input_shape += scheme["actions_onehot"]["vshape"][0]
        if self.args.obs_agent_id:
            input_shape += self.n_agents
        return input_shape


# from modules.agents import REGISTRY as agent_REGISTRY
# from components.action_selectors import REGISTRY as action_REGISTRY
# import torch as th

# from modules.comm.trigger_net import TriggerNet


# class TriggerCommMAC:
#     """
#     QMIX-style MAC + TriggerNet.
#     - agent 输出 Q(s,a) (agent_output_type='q')
#     - triggers 来自 agent hidden features (RNN hidden)
#     - learner 可用 self.mac.get_last_triggers() 做 trigger_rate / L_comm 统计与正则
#     """
#     def __init__(self, scheme, groups, args):
#         self.n_agents = args.n_agents
#         self.args = args

#         input_shape = self._get_input_shape(scheme)

#         # build agent
#         self._build_agents(input_shape)
#         self.agent_output_type = args.agent_output_type  # should be 'q'
#         self.action_selector = action_REGISTRY[args.action_selector](args)

#         # trigger net
#         # 用 rnn_hidden_dim 作为 h_dim（最常见）
#         h_dim = getattr(args, "h_dim", getattr(args, "rnn_hidden_dim", 64))
#         trig_hidden = getattr(args, "trigger_hidden", 64)
#         trig_hard = bool(getattr(args, "trigger_hard", True))
#         self.trigger_net = TriggerNet(h_dim=h_dim, hidden_dim=trig_hidden, hard=trig_hard)

#         self.hidden_states = None
#         self._last_triggers = None  # [bs, A, 1]

#         # debug marker: 用于确认你跑的是你改的 MAC
#         if getattr(args, "debug_triggercomm", False):
#             print("[TriggerCommMAC] Initialized (custom trigger_comm_mac)")

#     def select_actions(self, ep_batch, t_ep, t_env, bs=slice(None), test_mode=False):
#         avail_actions = ep_batch["avail_actions"][:, t_ep]
#         agent_outputs = self.forward(ep_batch, t_ep, test_mode=test_mode)
#         chosen_actions = self.action_selector.select_action(
#             agent_outputs[bs], avail_actions[bs], t_env, test_mode=test_mode
#         )
#         return chosen_actions

#     def forward(self, ep_batch, t, test_mode=False):
#         agent_inputs = self._build_inputs(ep_batch, t)
#         avail_actions = ep_batch["avail_actions"][:, t]

#         # agent forward
#         agent_outs, self.hidden_states = self.agent(agent_inputs, self.hidden_states)
#         # agent_outs: [bs*A, n_actions]
#         # hidden_states: [bs*A, h_dim]

#         bs = ep_batch.batch_size
#         A = self.n_agents

#         h = self.hidden_states.view(bs, A, -1)  # [bs, A, h_dim]
#         triggers = self.trigger_net(h, test_mode=test_mode)  # [bs, A, 1]
#         self._last_triggers = triggers

#         # Mask unavailable actions (for safety)
#         reshaped_avail = avail_actions.reshape(bs * A, -1)
#         agent_outs[reshaped_avail == 0] = -1e10

#         return agent_outs.view(bs, A, -1)

#     def get_last_triggers(self):
#         return self._last_triggers

#     def init_hidden(self, batch_size):
#         self.hidden_states = self.agent.init_hidden().unsqueeze(0).expand(batch_size, self.n_agents, -1)

#     def parameters(self):
#         return list(self.agent.parameters()) + list(self.trigger_net.parameters())

#     def load_state(self, other_mac):
#         self.agent.load_state_dict(other_mac.agent.state_dict())
#         self.trigger_net.load_state_dict(other_mac.trigger_net.state_dict())

#     def cuda(self):
#         self.agent.cuda()
#         self.trigger_net.cuda()

#     def save_models(self, path):
#         th.save(self.agent.state_dict(), "{}/agent.th".format(path))
#         th.save(self.trigger_net.state_dict(), "{}/trigger_net.th".format(path))

#     def load_models(self, path):
#         self.agent.load_state_dict(th.load("{}/agent.th".format(path), map_location=lambda s, l: s))
#         self.trigger_net.load_state_dict(th.load("{}/trigger_net.th".format(path), map_location=lambda s, l: s))

#     def _build_agents(self, input_shape):
#         self.agent = agent_REGISTRY[self.args.agent](input_shape, self.args)

#     def _build_inputs(self, batch, t):
#         bs = batch.batch_size
#         inputs = [batch["obs"][:, t]]

#         if self.args.obs_last_action:
#             if t == 0:
#                 inputs.append(th.zeros_like(batch["actions_onehot"][:, t]))
#             else:
#                 inputs.append(batch["actions_onehot"][:, t - 1])

#         if self.args.obs_agent_id:
#             inputs.append(th.eye(self.n_agents, device=batch.device).unsqueeze(0).expand(bs, -1, -1))

#         inputs = th.cat([x.reshape(bs * self.n_agents, -1) for x in inputs], dim=1)
#         return inputs
    
#     def get_last_triggers(self):
#         return self._last_triggers


#     def _get_input_shape(self, scheme):
#         input_shape = scheme["obs"]["vshape"]
#         if self.args.obs_last_action:
#             input_shape += scheme["actions_onehot"]["vshape"][0]
#         if self.args.obs_agent_id:
#             input_shape += self.n_agents
#         return input_shape
