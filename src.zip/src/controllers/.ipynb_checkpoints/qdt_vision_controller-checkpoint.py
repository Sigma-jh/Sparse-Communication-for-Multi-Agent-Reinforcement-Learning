# -*- coding: utf-8 -*-
from __future__ import annotations
from typing import Any, Dict, List, Optional
import numpy as np
import torch as th
import torch.nn as nn

from modules.qdt_vision import VisionConfig, QDTVisionConfig, QDTControllerWithVision


class TriggerActor(nn.Module):
    """仅用于 VisionSignalProcessor 的 entropy-trigger（不要求太强）。"""
    def __init__(self, obs_dim: int, n_actions: int, hidden_dim: int = 128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(obs_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, n_actions),
        )

    def forward(self, x: th.Tensor) -> th.Tensor:
        return self.net(x)


class QDTVisionMAC:
    """
    PyMARL MAC interface:
      - __init__(scheme, groups, args)
      - init_hidden(batch_size)
      - select_actions(batch, t_ep, t_env, test_mode) -> [bs, n_agents]
      - get_last_extra() -> dict (for runner to store in EpisodeBatch)
    """
    def __init__(self, scheme, groups, args):
        self.args = args
        self.device = th.device(args.device)

        self.n_agents = args.n_agents
        self.n_actions = args.n_actions

        obs_vshape = scheme["obs"]["vshape"]
        if isinstance(obs_vshape, int):
            self.obs_dim = obs_vshape
        else:
            self.obs_dim = int(np.prod(obs_vshape))

        # ---------------- Vision config (from yaml args) ----------------
        vision_cfg = VisionConfig(
            use_cnn=getattr(args, "vision_use_cnn", False),
            img_size=tuple(getattr(args, "vision_img_size", (30, 30))),
            img_channels=getattr(args, "vision_img_channels", 1),
            cnn_embed_dim=getattr(args, "vision_cnn_embed_dim", 128),
            cnn_to_obs=getattr(args, "vision_cnn_to_obs", False),
            cnn_to_state=getattr(args, "vision_cnn_to_state", False),

            view_size=getattr(args, "vision_view_size", 8.0),
            max_friend=getattr(args, "vision_max_friend", 7),
            max_enemy=getattr(args, "vision_max_enemy", 16),
            append_pos_to_obs=getattr(args, "vision_append_pos_to_obs", True),
            append_pos_to_state=getattr(args, "vision_append_pos_to_state", True),

            embed_dim=getattr(args, "vision_embed_dim", 128),
            use_modalign=getattr(args, "vision_use_modalign", True),
            append_mod_to_obs=getattr(args, "vision_append_mod_to_obs", True),
            append_mod_to_state=getattr(args, "vision_append_mod_to_state", True),

            add_trigger_bit=getattr(args, "vision_add_trigger_bit", True),
            tau_H=getattr(args, "vision_tau_H", 1.9),
            use_deltaR=getattr(args, "vision_use_deltaR", False),
            tau_R=getattr(args, "vision_tau_R", 0.5),
            trigger_to=getattr(args, "vision_trigger_to", "obs"),
        )

        # ---------------- QDT config ----------------
        qdt_cfg = QDTVisionConfig(
            vision_cfg=vision_cfg,
            n_actions=self.n_actions,
            hidden_dim=getattr(args, "qdt_hidden_dim", vision_cfg.embed_dim),
            act_embed_dim=getattr(args, "qdt_act_embed_dim", 32),
            n_heads=getattr(args, "qdt_n_heads", 4),
            n_layers=getattr(args, "qdt_n_layers", 2),
        )

        self.qdt = QDTControllerWithVision(qdt_cfg).to(self.device)
        self.trigger_actor = TriggerActor(self.obs_dim, self.n_actions).to(self.device)

        # neighbor mask: fully-connected without self
        neigh = th.ones(self.n_agents, self.n_agents, device=self.device) - th.eye(self.n_agents, device=self.device)
        self.neighbor_mask = neigh

        self._last_actions: Optional[th.Tensor] = None
        self._last_extra: Dict[str, Any] = {}

        # runner will inject env
        self.env = None

        # ---- epsilon-greedy exploration (train only) ----
        self.eps_start = float(getattr(args, "epsilon_start", 1.0))
        self.eps_finish = float(getattr(args, "epsilon_finish", 0.05))
        self.eps_anneal_time = int(getattr(args, "epsilon_anneal_time", 500000))

    def _epsilon(self, t_env: int) -> float:
        if self.eps_anneal_time <= 0:
            return self.eps_finish
        frac = min(1.0, float(t_env) / float(self.eps_anneal_time))
        return self.eps_start + frac * (self.eps_finish - self.eps_start)

    def init_hidden(self, batch_size: int):
        self._last_actions = th.zeros(batch_size, self.n_agents, device=self.device, dtype=th.long)

    def get_last_extra(self) -> Dict[str, Any]:
        return self._last_extra

    def parameters(self):
        # 建议把 trigger_actor 也交给 learner 优化（否则 trigger 相关网络永远不学）
        for p in self.qdt.parameters():
            yield p
        for p in self.trigger_actor.parameters():
            yield p

    def cuda(self):
        self.qdt.cuda()
        self.trigger_actor.cuda()

    # ---------------- helpers ----------------
    @staticmethod
    def _first_existing(d: Dict[str, Any], keys: List[str]) -> Optional[Any]:
        for k in keys:
            if k in d and d[k] is not None:
                return d[k]
        return None

    def _avail_bool(self, avail_actions_np_list: List[np.ndarray]) -> th.Tensor:
        # [A, n_actions] bool
        return th.as_tensor(np.stack(avail_actions_np_list, axis=0), device=self.device).bool()

    def _compute_probs_from_logits(self, logits: th.Tensor, avail_actions_np_list: List[np.ndarray]) -> th.Tensor:
        """
        logits: [A, n_actions]
        """
        avail = self._avail_bool(avail_actions_np_list)  # [A, n_actions]
        logits = logits.masked_fill(~avail, -1e10)
        return th.softmax(logits, dim=-1)

    def _mask_and_renorm_probs(self, prob: th.Tensor, avail_actions_np_list: List[np.ndarray]) -> th.Tensor:
        """
        prob: [A, n_actions] 可能不是严格归一化，也可能含非法动作概率
        """
        avail = self._avail_bool(avail_actions_np_list)  # [A, n_actions]
        prob = prob.clamp_min(0.0) * avail.float()
        s = prob.sum(dim=-1, keepdim=True)  # [A,1]

        # 若某个 agent 的 prob 全 0，则回退到 legal uniform
        zero = (s <= 1e-12)
        if zero.any():
            legal = avail.float()
            denom = legal.sum(dim=-1, keepdim=True).clamp_min(1.0)
            uniform = legal / denom
            prob = th.where(zero, uniform, prob / s.clamp_min(1e-12))
        else:
            prob = prob / s.clamp_min(1e-12)

        return prob

    @th.no_grad()
    def select_actions(self, batch, t_ep: int, t_env: int, test_mode: bool = False):
        assert self.env is not None, "EpisodeRunner.setup() must inject env: self.mac.env = self.env"
        assert self._last_actions is not None, "Call mac.init_hidden(batch_size) before select_actions."

        obs_t = batch["obs"][:, t_ep]               # [bs, A, obs_dim]
        state_t = batch["state"][:, t_ep]           # [bs, state_dim]
        avail_t = batch["avail_actions"][:, t_ep]   # [bs, A, n_actions]

        bs = obs_t.shape[0]
        actions_out, probs_out, triggers_out, z_out, state_aug_out = [], [], [], [], []

        for b in range(bs):
            obs_list: List[np.ndarray] = [obs_t[b, i].detach().cpu().numpy() for i in range(self.n_agents)]
            state_np: np.ndarray = state_t[b].detach().cpu().numpy()
            avail_list: List[np.ndarray] = [avail_t[b, i].detach().cpu().numpy() for i in range(self.n_agents)]
            last_actions_b = self._last_actions[b]

            out = self.qdt.forward_step(
                env=self.env,
                obs_list=obs_list,
                state=state_np,
                avail_actions=avail_list,
                neighbor_mask=self.neighbor_mask,
                last_actions=last_actions_b,
                R_hat_scalar=0.0,
                R_actual_scalar=0.0,
                actor_for_trigger=self.trigger_actor,
                greedy=bool(test_mode and getattr(self.args, "test_greedy", True)),
            )

            # 只打印一次 keys（可留着，确认无误后可删）
            if t_ep == 0 and b == 0 and getattr(self.args, "debug_qdt_keys", False):
                print("[DEBUG] forward_step keys:", list(out.keys()))
                if "vision_out" in out and isinstance(out["vision_out"], dict):
                    print("[DEBUG] vision_out keys:", list(out["vision_out"].keys()))

            # -------- action fallback (先拿 forward_step 的动作，后面会被 prob 决策覆盖) --------
            act_raw = self._first_existing(out, ["actions", "action", "chosen_actions"])
            if act_raw is not None:
                act = th.as_tensor(act_raw, device=self.device).long().view(-1)  # [A]
            else:
                act = th.zeros(self.n_agents, device=self.device, dtype=th.long)

            # -------- probs (robust) --------
            probs_raw = self._first_existing(out, ["probs", "beta", "pi", "action_probs"])

            if probs_raw is not None:
                prob = th.as_tensor(probs_raw, dtype=th.float32, device=self.device)  # [A, n_actions]
                if prob.dim() != 2 or prob.shape[-1] != self.n_actions:
                    raise ValueError(f"Bad probs shape {tuple(prob.shape)} expected [A,{self.n_actions}]")
                prob = self._mask_and_renorm_probs(prob, avail_list)
            else:
                logits_raw = self._first_existing(out, ["logits", "action_logits", "agent_outs"])
                if logits_raw is None:
                    raise KeyError(f"forward_step did not return probs nor logits. keys={list(out.keys())}")
                logits = th.as_tensor(logits_raw, dtype=th.float32, device=self.device)  # [A, n_actions]
                if logits.dim() != 2 or logits.shape[-1] != self.n_actions:
                    raise ValueError(f"Bad logits shape {tuple(logits.shape)} expected [A,{self.n_actions}]")
                prob = self._compute_probs_from_logits(logits, avail_list)  # [A, n_actions]

            # -------- choose actions from prob (IMPORTANT: prob 已定义后再用) --------
            # -------- choose actions from prob (RECOMMENDED) --------
            eps = 0.0 if test_mode else self._epsilon(t_env)

# test_greedy: 测试时是否强制贪心
            test_greedy = bool(getattr(self.args, "test_greedy", True))
            use_greedy = bool(test_mode and test_greedy)

            for i in range(self.n_agents):
    # 训练：epsilon 概率随机合法动作（uniform over legal）
                if (not test_mode) and (np.random.rand() < eps):
                    legal = np.where(avail_list[i] > 0)[0]
                    if legal.size > 0:
                        act[i] = int(np.random.choice(legal))
                    else:
            # 极端情况：没有合法动作就退回 argmax
                        act[i] = int(th.argmax(prob[i]).item())
                else:
                    if use_greedy:
                                    # 测试：贪心
                        act[i] = int(th.argmax(prob[i]).item())
                    else:
                        # 训练：按分布采样（天然探索）
                        dist = th.distributions.Categorical(probs=prob[i])
                        act[i] = int(dist.sample().item())

            # -------- trigger (robust) --------
            trig_raw = self._first_existing(out, ["trigger", "triggers", "trigger_bits"])
            if trig_raw is None:
                trig = th.zeros(self.n_agents, device=self.device, dtype=th.float32)
            else:
                trig = th.as_tensor(trig_raw, dtype=th.float32, device=self.device).view(-1)  # [A]
            trig = trig.unsqueeze(-1)  # [A, 1]

            # -------- z (robust) --------
            z_raw = self._first_existing(out, ["z", "latent", "h", "emb"])
            if z_raw is None:
                raise KeyError(f"forward_step missing z/latent. keys={list(out.keys())}")
            z = th.as_tensor(z_raw, dtype=th.float32, device=self.device)  # [A, d]

            # -------- state_aug (robust) --------
            state_aug = None
            if "vision_out" in out and isinstance(out["vision_out"], dict):
                state_aug = out["vision_out"].get("state_aug", None)
            if state_aug is None:
                state_aug = self._first_existing(out, ["state_aug", "aug_state"])

            if state_aug is None:
                # 如果你们暂时没有 state_aug，就用原 state 替代（保证 pipeline 先跑起来）
                state_aug = state_np

            state_aug = th.as_tensor(state_aug, dtype=th.float32, device=self.device).view(-1)  # [S_aug]

            # collect
            actions_out.append(act)
            probs_out.append(prob)
            triggers_out.append(trig)
            z_out.append(z)
            state_aug_out.append(state_aug)

            self._last_actions[b] = act

        actions = th.stack(actions_out, 0)           # [bs, A]
        probs = th.stack(probs_out, 0)               # [bs, A, n_actions]
        triggers = th.stack(triggers_out, 0)         # [bs, A, 1]
        z = th.stack(z_out, 0)                       # [bs, A, d]
        state_aug = th.stack(state_aug_out, 0)       # [bs, S_aug]

        self._last_extra = {
            "probs": probs,
            "triggers": triggers,
            "z": z,
            "state_aug": state_aug,
        }
        return actions
