REGISTRY = {}

from .basic_controller import BasicMAC
REGISTRY["basic_mac"] = BasicMAC

from .trigger_comm_controller import TriggerCommMAC
REGISTRY["trigger_comm_mac"] = TriggerCommMAC

from .qdt_vision_controller import QDTVisionMAC
REGISTRY["qdt_vision_mac"] = QDTVisionMAC
