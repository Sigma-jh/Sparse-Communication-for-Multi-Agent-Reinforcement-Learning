import torch as th
from torch.distributions import Categorical


class MultinomialActionSelector:
    def __init__(self, args):
        self.args = args
        # 为了兼容 BasicMAC.forward 里对 self.action_selector.epsilon 的访问
        self.epsilon = 0.0

    def select_action(self, agent_inputs, avail_actions, t_env, test_mode=False):
        """
        agent_inputs: [bs, n_agents, n_actions]，这里默认已经是 softmax 后的概率
        avail_actions: [bs, n_agents, n_actions]
        """
        probs = agent_inputs.clone()

        # mask 不可用动作
        probs[avail_actions == 0] = 0.0

        # 防止一整行都为 0
        probs_sum = probs.sum(dim=-1, keepdim=True)
        probs_sum[probs_sum == 0] = 1.0
        probs = probs / probs_sum

        if test_mode and getattr(self.args, "test_greedy", True):
            picked_actions = probs.max(dim=-1)[1]
        else:
            dist = Categorical(probs=probs)
            picked_actions = dist.sample()

        return picked_actions
