import torch as th
from torch.distributions import Categorical

REGISTRY = {}

from .epsilon_schedules import DecayThenFlatSchedule


class MultinomialActionSelector:
    def __init__(self, args):
        self.args = args
        # 兼容 BasicMAC.forward 里可能访问 self.action_selector.epsilon
        self.epsilon = 0.0

    def select_action(self, agent_inputs, avail_actions, t_env, test_mode=False):
        """
        agent_inputs: [bs, n_agents, n_actions]，默认已经是 softmax 后概率
        avail_actions: [bs, n_agents, n_actions]
        """
        probs = agent_inputs.clone()

        # mask unavailable actions
        probs[avail_actions == 0] = 0.0

        probs_sum = probs.sum(dim=-1, keepdim=True)
        probs_sum[probs_sum == 0] = 1.0
        probs = probs / probs_sum

        if test_mode and getattr(self.args, "test_greedy", True):
            picked_actions = probs.max(dim=-1)[1]
        else:
            dist = Categorical(probs=probs)
            picked_actions = dist.sample()

        return picked_actions.unsqueeze(-1)


class EpsilonGreedyActionSelector:
    def __init__(self, args):
        self.args = args

        self.schedule = DecayThenFlatSchedule(
            args.epsilon_start,
            args.epsilon_finish,
            args.epsilon_anneal_time,
            decay="linear"
        )
        self.epsilon = self.schedule.eval(0)

    def select_action(self, agent_inputs, avail_actions, t_env, test_mode=False):
        # agent_inputs: Q-values
        self.epsilon = self.schedule.eval(t_env)

        if test_mode:
            self.epsilon = 0.0

        masked_q_values = agent_inputs.clone()
        masked_q_values[avail_actions == 0.0] = -float("inf")

        random_numbers = th.rand_like(agent_inputs[:, :, 0])
        pick_random = (random_numbers < self.epsilon).long()

        random_actions = Categorical(avail_actions.float()).sample().long()
        greedy_actions = masked_q_values.max(dim=2)[1]

        picked_actions = pick_random * random_actions + (1 - pick_random) * greedy_actions
        return picked_actions.unsqueeze(-1)


REGISTRY["multinomial"] = MultinomialActionSelector
REGISTRY["epsilon_greedy"] = EpsilonGreedyActionSelector
