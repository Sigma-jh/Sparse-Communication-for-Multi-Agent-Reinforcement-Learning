# # from envs import REGISTRY as env_REGISTRY
# # from functools import partial
# # from components.episode_buffer import EpisodeBatch
# # import numpy as np


# # class EpisodeRunner:

# #     def __init__(self, args, logger):
# #         self.args = args
# #         self.logger = logger
# #         self.batch_size = self.args.batch_size_run
# #         assert self.batch_size == 1

# #         self.env = env_REGISTRY[self.args.env](**self.args.env_args)
# #         self.episode_limit = self.env.episode_limit
# #         self.t = 0
# #         self.t_env = 0

# #         self.train_returns = []
# #         self.test_returns = []
# #         self.train_stats = {}
# #         self.test_stats = {}

# #         # Log the first run
# #         self.log_train_stats_t = -1000000

# #     def setup(self, scheme, groups, preprocess, mac):
# #         self.new_batch = partial(
# #             EpisodeBatch,
# #             scheme,
# #             groups,
# #             self.batch_size,
# #             self.episode_limit + 1,
# #             preprocess=preprocess,
# #             device=self.args.device
# #         )
# #         self.mac = mac

# #         # ✅ 注入 env 给 MAC/Controller（你们的 VisionSignalProcessor 需要 env）
# #         if hasattr(self.mac, "env"):
# #             self.mac.env = self.env

# #     def get_env_info(self):
# #         return self.env.get_env_info()

# #     def save_replay(self):
# #         self.env.save_replay()

# #     def close_env(self):
# #         self.env.close()

# #     def reset(self):
# #         self.batch = self.new_batch()
# #         self.env.reset()
# #         self.t = 0

# #     def _maybe_store_extra(self, ts: int):
# #         """
# #         把你们算法在 select_actions 后缓存的 extra 写进 EpisodeBatch。
# #         期望 self.mac.get_last_extra() -> dict，包含：
# #           - probs:      [bs, n_agents, n_actions]
# #           - triggers:   [bs, n_agents, 1]
# #           - z:          [bs, n_agents, d]
# #           - state_aug:  [bs, state_aug_dim]
# #         注意：batch_size_run==1，所以 update 时 value 需要是 list 包一层。
# #         """
# #         if not hasattr(self.mac, "get_last_extra"):
# #             return

# #         extra = self.mac.get_last_extra()
# #         if not extra:
# #             return

# #         upd = {}

# #         def _to_numpy(x):
# #             if hasattr(x, "detach"):
# #                 x = x.detach()
# #             if hasattr(x, "cpu"):
# #                 x = x.cpu()
# #             if hasattr(x, "numpy"):
# #                 x = x.numpy()
# #             return x

# #         # probs
# #         if "probs" in extra and extra["probs"] is not None:
# #             p = _to_numpy(extra["probs"])
# #             upd["probs"] = [p[0]]  # [A, n_actions]

# #         # triggers
# #         if "triggers" in extra and extra["triggers"] is not None:
# #             tr = _to_numpy(extra["triggers"])
# #             upd["triggers"] = [tr[0]]  # [A, 1]

# #         # z
# #         if "z" in extra and extra["z"] is not None:
# #             z = _to_numpy(extra["z"])
# #             upd["z"] = [z[0]]  # [A, d]

# #         # state_aug
# #         if "state_aug" in extra and extra["state_aug"] is not None:
# #             sa = _to_numpy(extra["state_aug"])
# #             upd["state_aug"] = [sa[0]]  # [state_aug_dim]

# #         if upd:
# #             self.batch.update(upd, ts=ts)

# #     def run(self, test_mode=False):
# #         self.reset()

# #         terminated = False
# #         episode_return = 0
# #         self.mac.init_hidden(batch_size=self.batch_size)

# #         while not terminated:

# #             pre_transition_data = {
# #                 "state": [self.env.get_state()],
# #                 "avail_actions": [self.env.get_avail_actions()],
# #                 "obs": [self.env.get_obs()]
# #             }
# #             self.batch.update(pre_transition_data, ts=self.t)

# #             # 选择动作（bs=1），actions shape: [1, n_agents]
# #             actions = self.mac.select_actions(self.batch, t_ep=self.t, t_env=self.t_env, test_mode=test_mode)

# #             # ✅ 把本步 extra 写入 batch（属于 pre-transition 时刻）
# #             self._maybe_store_extra(ts=self.t)

# #             reward, terminated, env_info = self.env.step(actions[0])
# #             episode_return += reward

# #             post_transition_data = {
# #                 "actions": actions,
# #                 "reward": [(reward,)],
# #                 "terminated": [(terminated != env_info.get("episode_limit", False),)],
# #             }
# #             self.batch.update(post_transition_data, ts=self.t)

# #             self.t += 1

# #         # 最后一个 state
# #         last_data = {
# #             "state": [self.env.get_state()],
# #             "avail_actions": [self.env.get_avail_actions()],
# #             "obs": [self.env.get_obs()]
# #         }
# #         self.batch.update(last_data, ts=self.t)

# #         # 末尾也 select 一次 actions（PyMARL 原本就这样）
# #         actions = self.mac.select_actions(self.batch, t_ep=self.t, t_env=self.t_env, test_mode=test_mode)

# #         # ✅ 末尾这个时刻也把 extra 存一下（让 learner 可以用到最后一步的 z/state_aug 等）
# #         self._maybe_store_extra(ts=self.t)

# #         self.batch.update({"actions": actions}, ts=self.t)

# #         # stats / logging
# #         cur_stats = self.test_stats if test_mode else self.train_stats
# #         cur_returns = self.test_returns if test_mode else self.train_returns
# #         log_prefix = "test_" if test_mode else ""

# #         cur_stats.update({k: cur_stats.get(k, 0) + env_info.get(k, 0) for k in set(cur_stats) | set(env_info)})
# #         cur_stats["n_episodes"] = 1 + cur_stats.get("n_episodes", 0)
# #         cur_stats["ep_length"] = self.t + cur_stats.get("ep_length", 0)

# #         if not test_mode:
# #             self.t_env += self.t

# #         cur_returns.append(episode_return)

# #         if test_mode and (len(self.test_returns) == self.args.test_nepisode):
# #             self._log(cur_returns, cur_stats, log_prefix)
# #         elif self.t_env - self.log_train_stats_t >= self.args.runner_log_interval:
# #             self._log(cur_returns, cur_stats, log_prefix)
# #             if hasattr(self.mac, "action_selector") and hasattr(self.mac.action_selector, "epsilon"):
# #                 self.logger.log_stat("epsilon", self.mac.action_selector.epsilon, self.t_env)
# #             self.log_train_stats_t = self.t_env

# #         return self.batch

# #     def _log(self, returns, stats, prefix):
# #         self.logger.log_stat(prefix + "return_mean", np.mean(returns), self.t_env)
# #         self.logger.log_stat(prefix + "return_std", np.std(returns), self.t_env)
# #         returns.clear()

# #         for k, v in stats.items():
# #             if k != "n_episodes":
# #                 self.logger.log_stat(prefix + k + "_mean", v / stats["n_episodes"], self.t_env)
# #         stats.clear()
# from envs import REGISTRY as env_REGISTRY
# from functools import partial
# from components.episode_buffer import EpisodeBatch
# import numpy as np

# # Optional metrics support (won't crash if metrics package is not ready)
# try:
#     from metrics import REGISTRY as metrics_REGISTRY  # you said you've created metrics code
# except Exception:
#     metrics_REGISTRY = None


# class EpisodeRunner:
#     def __init__(self, args, logger):
#         self.args = args
#         self.logger = logger
#         self.batch_size = self.args.batch_size_run
#         assert self.batch_size == 1

#         self.env = env_REGISTRY[self.args.env](**self.args.env_args)
#         self.episode_limit = self.env.episode_limit
#         self.t = 0
#         self.t_env = 0

#         self.train_returns = []
#         self.test_returns = []
#         self.train_stats = {}
#         self.test_stats = {}

#         # Log the first run
#         self.log_train_stats_t = -1000000

#         # ---- Metrics (custom) ----
#         # Expect args.metrics: list[str] or comma-separated string.
#         self.metrics = []
#         self._init_metrics()

#     def _init_metrics(self):
#         if metrics_REGISTRY is None:
#             # metrics package not importable yet; keep running without metrics
#             return

#         names = getattr(self.args, "metrics", [])
#         if isinstance(names, str):
#             # allow "a,b,c"
#             names = [x.strip() for x in names.split(",") if x.strip()]

#         if not names:
#             return

#         for n in names:
#             if n not in metrics_REGISTRY:
#                 print(f"[WARN][EpisodeRunner] metrics '{n}' not found in metrics.REGISTRY, skip.")
#                 continue
#             try:
#                 self.metrics.append(metrics_REGISTRY[n](self.args))
#                 print(f"[INFO][EpisodeRunner] metrics enabled: {n}")
#             except Exception as e:
#                 print(f"[WARN][EpisodeRunner] failed to init metrics '{n}': {e}")

#     def setup(self, scheme, groups, preprocess, mac):
#         self.new_batch = partial(
#             EpisodeBatch,
#             scheme,
#             groups,
#             self.batch_size,
#             self.episode_limit + 1,
#             preprocess=preprocess,
#             device=self.args.device
#         )
#         self.mac = mac

#         # ✅ 注入 env 给 MAC/Controller（你们的 VisionSignalProcessor 需要 env）
#         if hasattr(self.mac, "env"):
#             self.mac.env = self.env

#     def get_env_info(self):
#         return self.env.get_env_info()

#     def save_replay(self):
#         self.env.save_replay()

#     def close_env(self):
#         self.env.close()

#     def reset(self):
#         self.batch = self.new_batch()
#         self.env.reset()
#         self.t = 0

#         # reset metrics
#         for m in self.metrics:
#             try:
#                 # allow either reset(env) or reset()
#                 if hasattr(m, "reset"):
#                     if m.reset.__code__.co_argcount >= 2:
#                         m.reset(self.env)
#                     else:
#                         m.reset()
#             except Exception as e:
#                 print(f"[WARN][EpisodeRunner] metrics reset failed: {type(m).__name__}: {e}")

#     def _maybe_store_extra(self, ts: int):
#         """
#         把你们算法在 select_actions 后缓存的 extra 写进 EpisodeBatch。
#         期望 self.mac.get_last_extra() -> dict，包含：
#           - probs:      [bs, n_agents, n_actions]
#           - triggers:   [bs, n_agents, 1]
#           - z:          [bs, n_agents, d]
#           - state_aug:  [bs, state_aug_dim]
#         注意：batch_size_run==1，所以 update 时 value 需要是 list 包一层。
#         """
#         if not hasattr(self.mac, "get_last_extra"):
#             return

#         extra = self.mac.get_last_extra()
#         if not extra:
#             return

#         upd = {}

#         def _to_numpy(x):
#             if hasattr(x, "detach"):
#                 x = x.detach()
#             if hasattr(x, "cpu"):
#                 x = x.cpu()
#             if hasattr(x, "numpy"):
#                 x = x.numpy()
#             return x

#         # probs
#         if "probs" in extra and extra["probs"] is not None:
#             p = _to_numpy(extra["probs"])
#             upd["probs"] = [p[0]]  # [A, n_actions]

#         # triggers
#         if "triggers" in extra and extra["triggers"] is not None:
#             tr = _to_numpy(extra["triggers"])
#             upd["triggers"] = [tr[0]]  # [A, 1]

#         # z
#         if "z" in extra and extra["z"] is not None:
#             z = _to_numpy(extra["z"])
#             upd["z"] = [z[0]]  # [A, d]

#         # state_aug
#         if "state_aug" in extra and extra["state_aug"] is not None:
#             sa = _to_numpy(extra["state_aug"])
#             upd["state_aug"] = [sa[0]]  # [state_aug_dim]

#         if upd:
#             self.batch.update(upd, ts=ts)

#     def _update_metrics_step(self, actions, reward, terminated, env_info, test_mode: bool):
#         """
#         Call custom metrics every env step.
#         - actions: tensor [1, n_agents] (we pass actions[0])
#         - env_info: dict from SMAC
#         Return: dict of metrics (already "episode-summed" or "step-value", up to your implementation)
#         """
#         if not self.metrics:
#             return {}

#         out_all = {}
#         for m in self.metrics:
#             try:
#                 if hasattr(m, "step"):
#                     # provide rich context; metrics can ignore what it doesn't need
#                     out = m.step(
#                         env=self.env,
#                         t=self.t,
#                         t_env=self.t_env,
#                         actions=actions[0],
#                         reward=reward,
#                         terminated=terminated,
#                         env_info=env_info,
#                         test_mode=test_mode,
#                     )
#                     if isinstance(out, dict):
#                         out_all.update(out)
#             except Exception as e:
#                 print(f"[WARN][EpisodeRunner] metrics step failed: {type(m).__name__}: {e}")
#         return out_all

#     def _update_metrics_episode_end(self, episode_return, test_mode: bool):
#         """
#         Call metrics at end of an episode.
#         Return: dict of episode-level metrics
#         """
#         if not self.metrics:
#             return {}

#         out_all = {}
#         for m in self.metrics:
#             try:
#                 if hasattr(m, "episode_end"):
#                     out = m.episode_end(
#                         env=self.env,
#                         t=self.t,
#                         t_env=self.t_env,
#                         episode_return=episode_return,
#                         test_mode=test_mode,
#                     )
#                     if isinstance(out, dict):
#                         out_all.update(out)
#             except Exception as e:
#                 print(f"[WARN][EpisodeRunner] metrics episode_end failed: {type(m).__name__}: {e}")
#         return out_all

#     def run(self, test_mode=False):
#         self.reset()

#         terminated = False
#         episode_return = 0
#         self.mac.init_hidden(batch_size=self.batch_size)

#         while not terminated:
#             pre_transition_data = {
#                 "state": [self.env.get_state()],
#                 "avail_actions": [self.env.get_avail_actions()],
#                 "obs": [self.env.get_obs()]
#             }
#             self.batch.update(pre_transition_data, ts=self.t)

#             # 选择动作（bs=1），actions shape: [1, n_agents]
#             actions = self.mac.select_actions(self.batch, t_ep=self.t, t_env=self.t_env, test_mode=test_mode)

#             # ✅ 把本步 extra 写入 batch（属于 pre-transition 时刻）
#             self._maybe_store_extra(ts=self.t)

#             reward, terminated, env_info = self.env.step(actions[0])
#             episode_return += reward

#             # ---- metrics step ----
#             metric_out = self._update_metrics_step(
#                 actions=actions,
#                 reward=reward,
#                 terminated=terminated,
#                 env_info=env_info,
#                 test_mode=test_mode,
#             )

#             post_transition_data = {
#                 "actions": actions,
#                 "reward": [(reward,)],
#                 "terminated": [(terminated != env_info.get("episode_limit", False),)],
#             }
#             self.batch.update(post_transition_data, ts=self.t)

#             # If you also want per-timestep metrics stored in batch, you can uncomment this:
#             # if metric_out:
#             #     self.batch.update({k: [(float(v),)] for k, v in metric_out.items()}, ts=self.t)

#             # accumulate metrics into stats (episode-summed; logger will divide by n_episodes later)
#             if metric_out:
#                 cur_stats = self.test_stats if test_mode else self.train_stats
#                 for k, v in metric_out.items():
#                     try:
#                         cur_stats[k] = cur_stats.get(k, 0) + float(v)
#                     except Exception:
#                         pass

#             self.t += 1

#         # 最后一个 state
#         last_data = {
#             "state": [self.env.get_state()],
#             "avail_actions": [self.env.get_avail_actions()],
#             "obs": [self.env.get_obs()]
#         }
#         self.batch.update(last_data, ts=self.t)

#         # 末尾也 select 一次 actions（PyMARL 原本就这样）
#         actions = self.mac.select_actions(self.batch, t_ep=self.t, t_env=self.t_env, test_mode=test_mode)

#         # ✅ 末尾这个时刻也把 extra 存一下
#         self._maybe_store_extra(ts=self.t)

#         self.batch.update({"actions": actions}, ts=self.t)

#         # ---- metrics episode end ----
#         metric_out_end = self._update_metrics_episode_end(
#             episode_return=episode_return,
#             test_mode=test_mode,
#         )
#         if metric_out_end:
#             cur_stats = self.test_stats if test_mode else self.train_stats
#             for k, v in metric_out_end.items():
#                 try:
#                     cur_stats[k] = cur_stats.get(k, 0) + float(v)
#                 except Exception:
#                     pass

#         # stats / logging
#         cur_stats = self.test_stats if test_mode else self.train_stats
#         cur_returns = self.test_returns if test_mode else self.train_returns
#         log_prefix = "test_" if test_mode else ""

#         cur_stats.update({k: cur_stats.get(k, 0) + env_info.get(k, 0) for k in set(cur_stats) | set(env_info)})
#         cur_stats["n_episodes"] = 1 + cur_stats.get("n_episodes", 0)
#         cur_stats["ep_length"] = self.t + cur_stats.get("ep_length", 0)

#         if not test_mode:
#             self.t_env += self.t

#         cur_returns.append(episode_return)

#         if test_mode and (len(self.test_returns) == self.args.test_nepisode):
#             self._log(cur_returns, cur_stats, log_prefix)
#         elif self.t_env - self.log_train_stats_t >= self.args.runner_log_interval:
#             self._log(cur_returns, cur_stats, log_prefix)
#             if hasattr(self.mac, "action_selector") and hasattr(self.mac.action_selector, "epsilon"):
#                 self.logger.log_stat("epsilon", self.mac.action_selector.epsilon, self.t_env)
#             self.log_train_stats_t = self.t_env

#         return self.batch

#     def _log(self, returns, stats, prefix):
#         self.logger.log_stat(prefix + "return_mean", np.mean(returns), self.t_env)
#         self.logger.log_stat(prefix + "return_std", np.std(returns), self.t_env)
#         returns.clear()

#         for k, v in stats.items():
#             if k != "n_episodes":
#                 self.logger.log_stat(prefix + k + "_mean", v / stats["n_episodes"], self.t_env)
#         stats.clear()
# src/runners/episode_runner.py
# from envs import REGISTRY as env_REGISTRY
# from functools import partial
# from components.episode_buffer import EpisodeBatch
# import numpy as np

# import torch as th
# from utils.trigger_metrics import TriggerMetrics


# class EpisodeRunner:
#     def __init__(self, args, logger):
#         self.args = args
#         self.logger = logger
#         self.batch_size = self.args.batch_size_run
#         assert self.batch_size == 1

#         self.env = env_REGISTRY[self.args.env](**self.args.env_args)
#         self.episode_limit = self.env.episode_limit
#         self.t = 0

#         self.t_env = 0
#         self.last_log_T = 0


#         self.train_returns = []
#         self.test_returns = []
#         self.train_stats = {}
#         self.test_stats = {}

#         # --- trigger behaviour metrics (focus fire / entropy / kiting / trigger rate) ---
#         # NOTE: move_action_ids may differ by SMAC version; you can pass a better list from env if available.
#         self.env_info = self.env.get_env_info()
#         _n_agents = self.env_info.get("n_agents", getattr(self.args, "n_agents", None))
#         _n_enemies = self.env_info.get("n_enemies", getattr(self.env, "n_enemies", 0) or 0)
#         _n_actions = self.env_info.get("n_actions", self.env_info.get("n_actions_total", 0))
#         if _n_agents is None or _n_enemies <= 0 or _n_actions <= 0:
#             self._tm = None
#         else:
#             self._tm = TriggerMetrics(
#                 n_agents=_n_agents,
#                 n_enemies=_n_enemies,
#                 n_actions_total=_n_actions,
#                 move_action_ids=getattr(self.args, "move_action_ids", None),
#             )

#     def setup(self, scheme, groups, preprocess, mac):
#         self.new_batch = partial(EpisodeBatch, scheme, groups, self.batch_size,
#                                  self.episode_limit + 1,
#                                  preprocess=preprocess,
#                                  device=self.args.device)
#         self.mac = mac

#         # 兼容：有些版本会在 __init__ 时就取 env_info
#         if not hasattr(self, "env_info") or self.env_info is None:
#             self.env_info = self.env.get_env_info()

#     def get_env_info(self):
#         return self.env.get_env_info()

#     def save_replay(self):
#         self.env.save_replay()

#     def close_env(self):
#         self.env.close()

#     def reset(self):
#         self.batch = self.new_batch()
#         self.env.reset()
#         self.t = 0

#         if hasattr(self, "_tm") and self._tm is not None:
#             self._tm.reset()

#     def run(self, test_mode=False):
#         self.reset()

#         terminated = False
#         episode_return = 0
#         self.mac.init_hidden(batch_size=self.batch_size)

#         while not terminated:
#             pre_transition_data = {
#                 "state": [self.env.get_state()],
#                 "avail_actions": [self.env.get_avail_actions()],
#                 "obs": [self.env.get_obs()]
#             }

#             self.batch.update(pre_transition_data, ts=self.t)

#             # Pass the entire batch of experiences up till now to the agents
#             actions = self.mac.select_actions(self.batch, t_ep=self.t, t_env=self.t_env, test_mode=test_mode)

#             reward, terminated, env_info = self.env.step(actions[0])
#             episode_return += reward

#             # --- trigger behaviour metrics ---
#             if hasattr(self, "_tm") and self._tm is not None:
#                 _tr = None
#                 if hasattr(self.mac, "get_last_extra"):
#                     try:
#                         _ex = self.mac.get_last_extra()
#                         _tr = _ex.get("triggers", None) if isinstance(_ex, dict) else None
#                     except Exception:
#                         _tr = None
#                 if _tr is None and hasattr(self.mac, "_last_triggers"):
#                     _tr = getattr(self.mac, "_last_triggers")
#                 self._tm.step(actions, float(reward), triggers=_tr)

#             post_transition_data = {
#                 "actions": actions,
#                 "reward": [(reward,)],
#                 "terminated": [(terminated != env_info.get("episode_limit", False),)],
#             }

#             self.batch.update(post_transition_data, ts=self.t)

#             # 你之前加的：把 triggers / msg 等 extra 存进 buffer
#             self._maybe_store_extra(ts=self.t)

#             self.t += 1

#         # last obs/state
#         last_data = {
#             "state": [self.env.get_state()],
#             "avail_actions": [self.env.get_avail_actions()],
#             "obs": [self.env.get_obs()]
#         }
#         self.batch.update(last_data, ts=self.t)

#         # Select actions in the last stored state
#         actions = self.mac.select_actions(self.batch, t_ep=self.t, t_env=self.t_env, test_mode=test_mode)
#         self.batch.update({"actions": actions}, ts=self.t)

#         # 终止时也存一次 extra（避免最后一步 trigger 丢失）
#         self._maybe_store_extra(ts=self.t)

#         cur_stats = self.test_stats if test_mode else self.train_stats
#         cur_returns = self.test_returns if test_mode else self.train_returns
#         log_prefix = "test_" if test_mode else ""
#         cur_stats.update({k: cur_stats.get(k, 0) + env_info.get(k, 0) for k in env_info})
#         cur_stats["n_episodes"] = 1 + cur_stats.get("n_episodes", 0)
#         cur_stats["ep_length"] = self.t + cur_stats.get("ep_length", 0)

#         if not test_mode:
#             self.t_env += self.t

#         cur_returns.append(episode_return)

#         # --- log trigger behaviour metrics (episode-level) ---
#         if hasattr(self, "_tm") and self._tm is not None:
#             m = self._tm.summary()
#             rename = {
#                 "focus_max_mean": "focus_fire_mean",
#                 "kite_per_step": "kite_ratio",
#             }
#             for k, v in list(m.items()):
#                 kk = rename.get(k, k)
#                 if test_mode:
#                     kk = "test_" + kk
#                 self.logger.log_stat(kk, v, self.t_env)

#         if test_mode and (len(self.test_returns) == self.args.test_nepisode):
#             self._log(cur_returns, cur_stats, log_prefix)
#         elif self.t_env - self.last_log_T >= self.args.log_interval:
#             self._log(cur_returns, cur_stats, log_prefix)


#         return self.batch

#     def _maybe_store_extra(self, ts: int):
#         """
#         如果 MAC 提供 get_last_extra()，把返回的 dict 写入 EpisodeBatch
#         """
#         if not hasattr(self.mac, "get_last_extra"):
#             return
#         extra = self.mac.get_last_extra()
#         if not extra:
#             return

#         upd = {}
#         for k, v in extra.items():
#             upd[k] = v
#         try:
#             self.batch.update(upd, ts=ts)
#         except Exception:
#             # 如果 shape 不匹配，会报 Unsafe reshape；那说明 scheme 里没声明对应字段
#             pass

#     def _log(self, returns, stats, prefix):
#         self.logger.log_stat(prefix + "return_mean", np.mean(returns), self.t_env)
#         self.logger.log_stat(prefix + "return_std", np.std(returns), self.t_env)
#         returns.clear()

#         for k, v in stats.items():
#             if k != "n_episodes":
#                 self.logger.log_stat(prefix + k + "_mean", v / stats["n_episodes"], self.t_env)
#         stats.clear()
#         self.last_log_T = self.t_env
# from envs import REGISTRY as env_REGISTRY
# from functools import partial
# from components.episode_buffer import EpisodeBatch
# import numpy as np

# import torch as th
# from utils.trigger_metrics import TriggerMetrics
# from utils.distance_metrics import DistanceMetrics


# class EpisodeRunner:
#     def __init__(self, args, logger):
#         self.args = args
#         self.logger = logger
#         self.batch_size = self.args.batch_size_run
#         assert self.batch_size == 1

#         self.env = env_REGISTRY[self.args.env](**self.args.env_args)
#         self.episode_limit = self.env.episode_limit
#         self.t = 0

#         self.t_env = 0
#         self.last_log_T = 0

#         self.train_returns = []
#         self.test_returns = []
#         self.train_stats = {}
#         self.test_stats = {}

#         # --- env info ---
#         self.env_info = self.env.get_env_info()

#         # --- trigger behaviour metrics (focus fire / entropy / kiting / trigger rate) ---
#         _n_agents = self.env_info.get("n_agents", getattr(self.args, "n_agents", None))
#         _n_enemies = self.env_info.get("n_enemies", getattr(self.env, "n_enemies", 0) or 0)
#         _n_actions = self.env_info.get("n_actions", self.env_info.get("n_actions_total", 0))

#         if _n_agents is None or _n_enemies <= 0 or _n_actions <= 0:
#             self._tm = None
#         else:
#             self._tm = TriggerMetrics(
#                 n_agents=_n_agents,
#                 n_enemies=_n_enemies,
#                 n_actions_total=_n_actions,
#                 move_action_ids=getattr(self.args, "move_action_ids", None),
#             )

#         # --- distance metrics (ally dispersion/minsep/radius) ---
#         if _n_agents is None:
#             self._dm = None
#         else:
#             self._dm = DistanceMetrics(n_agents=int(_n_agents))

#         # debug control (optional)
#         self._dbg_enabled = bool(getattr(self.args, "debug_metrics", True))  # 默认 True 方便你排查
#         self._dbg_once_envinfo = False
#         self._dbg_once_dm = False
#         self._dbg_once_stats = False
#         self._dbg_ep_count = 0
#         self._dbg_dm_ep_print = 0

#     def setup(self, scheme, groups, preprocess, mac):
#         self.new_batch = partial(
#             EpisodeBatch, scheme, groups, self.batch_size,
#             self.episode_limit + 1,
#             preprocess=preprocess,
#             device=self.args.device
#         )
#         self.mac = mac

#         if not hasattr(self, "env_info") or self.env_info is None:
#             self.env_info = self.env.get_env_info()

#     def get_env_info(self):
#         return self.env.get_env_info()

#     def save_replay(self):
#         self.env.save_replay()

#     def close_env(self):
#         self.env.close()

#     def reset(self):
#         self.batch = self.new_batch()
#         self.env.reset()
#         self.t = 0

#         if getattr(self, "_tm", None) is not None:
#             self._tm.reset()

#         if getattr(self, "_dm", None) is not None:
#             self._dm.reset()

#     def run(self, test_mode=False):
#         self.reset()
#         if not hasattr(self, "_dbg_env_tree_once"):
#             self._dbg_env_tree_once = True
#             self._debug_print_env_tree()

#         terminated = False
#         episode_return = 0
#         self.mac.init_hidden(batch_size=self.batch_size)

#         while not terminated:
#             pre_transition_data = {
#                 "state": [self.env.get_state()],
#                 "avail_actions": [self.env.get_avail_actions()],
#                 "obs": [self.env.get_obs()]
#             }
#             self.batch.update(pre_transition_data, ts=self.t)

#             actions = self.mac.select_actions(
#                 self.batch, t_ep=self.t, t_env=self.t_env, test_mode=test_mode
#             )

#             reward, terminated, env_info = self.env.step(actions[0])
#             episode_return += reward

#             # ===== DEBUG A: check env_info keys that may overwrite =====
#             if self._dbg_enabled and (not self._dbg_once_envinfo):
#                 self._dbg_once_envinfo = True
#                 keys = [k for k in env_info.keys()
#                         if ("ally_" in k) or ("disp" in k) or ("minsep" in k) or ("radius" in k)]
#                 print("[DBG env_info ally-related keys]", keys)
#                 for k in keys:
#                     try:
#                         print(f"[DBG env_info] {k}={env_info.get(k)}")
#                     except Exception:
#                         pass

#             # ===== FIX: prevent env_info zeros overwriting our custom DistanceMetrics logs =====
#             for _k in ["ally_dispersion", "ally_minsep", "ally_radius",
#                        "ally_dispersion_mean", "ally_minsep_mean", "ally_radius_mean",
#                        "test_ally_dispersion_mean", "test_ally_minsep_mean", "test_ally_radius_mean"]:
#                 if _k in env_info:
#                     env_info.pop(_k, None)

#             # --- trigger behaviour metrics ---
#             if getattr(self, "_tm", None) is not None:
#                 _tr = None
#                 if hasattr(self.mac, "get_last_extra"):
#                     try:
#                         _ex = self.mac.get_last_extra()
#                         _tr = _ex.get("triggers", None) if isinstance(_ex, dict) else None
#                     except Exception:
#                         _tr = None
#                 if _tr is None and hasattr(self.mac, "_last_triggers"):
#                     _tr = getattr(self.mac, "_last_triggers")
#                 self._tm.step(actions, float(reward), triggers=_tr)

#             # --- distance metrics (after env.step, before t++) ---
#             if getattr(self, "_dm", None) is not None:
#                 ally_pos, ally_alive = self._get_ally_pos_alive()

#                 # ===== DEBUG B: check ally_pos/alive extraction (first 3 episodes only, at t=0) =====
#                 if self._dbg_enabled and self.t == 0 and self._dbg_ep_count < 3:
#                     self._dbg_ep_count += 1
#                     if ally_pos is None or ally_alive is None:
#                         print("[DBG pos] ally_pos/alive is None")
#                     else:
#                         P = np.asarray(ally_pos)
#                         A = np.asarray(ally_alive).astype(bool)
#                         print("[DBG pos] P.shape=", P.shape, "alive_cnt=", int(A.sum()))
#                         if P.size > 0:
#                             print("[DBG pos] P_head=", P[:min(3, P.shape[0])])
#                             print("[DBG pos] P_min=", float(P.min()), "P_max=", float(P.max()))
#                             if np.allclose(P, 0):
#                                 print("[DBG pos] WARNING: positions are all zeros")
#                             if int(A.sum()) >= 2:
#                                 Pa = P[A]
#                                 diff = Pa[:, None, :] - Pa[None, :, :]
#                                 D = np.sqrt((diff ** 2).sum(-1))
#                                 np.fill_diagonal(D, np.inf)
#                                 print("[DBG pos] pairwise_min=", float(D.min()),
#                                       "pairwise_mean=", float(D[np.isfinite(D)].mean()))

#                 self._dm.step(ally_pos, ally_alive)

#                 # ===== DEBUG: check dm summary after first step of first episode =====
#                 if self._dbg_enabled and self.t == 0 and (not self._dbg_once_dm):
#                     self._dbg_once_dm = True
#                     print("[DBG dm summary after step0]", self._dm.summary())

#             post_transition_data = {
#                 "actions": actions,
#                 "reward": [(reward,)],
#                 "terminated": [(terminated != env_info.get("episode_limit", False),)],
#             }
#             self.batch.update(post_transition_data, ts=self.t)
#             if self.t == 0 and not hasattr(self, "_dbg_state_obs_once"):
#                 self._dbg_state_obs_once = True
#                 s = np.asarray(self.env.get_state())
#                 obs = self.env.get_obs()
#                 o0 = np.asarray(obs[0]) if isinstance(obs, (list, tuple)) and len(obs) > 0 else None
#                 print("[DBG SO] state_shape:", s.shape, "state_head:", s[:40])
#                 if o0 is not None:
#                     print("[DBG SO] obs0_shape:", o0.shape, "obs0_head:", o0[:40])
#                 else:
#                     print("[DBG SO] obs0: None")


#             # store triggers/msg etc extra into buffer if available
#             self._maybe_store_extra(ts=self.t)

#             self.t += 1

#         # last obs/state
#         last_data = {
#             "state": [self.env.get_state()],
#             "avail_actions": [self.env.get_avail_actions()],
#             "obs": [self.env.get_obs()]
#         }
#         self.batch.update(last_data, ts=self.t)

#         actions = self.mac.select_actions(
#             self.batch, t_ep=self.t, t_env=self.t_env, test_mode=test_mode
#         )
#         self.batch.update({"actions": actions}, ts=self.t)

#         # store extra at terminal
#         self._maybe_store_extra(ts=self.t)

#         cur_stats = self.test_stats if test_mode else self.train_stats
#         cur_returns = self.test_returns if test_mode else self.train_returns
#         log_prefix = "test_" if test_mode else ""

#         cur_stats.update({k: cur_stats.get(k, 0) + env_info.get(k, 0) for k in env_info})
#         cur_stats["n_episodes"] = 1 + cur_stats.get("n_episodes", 0)
#         cur_stats["ep_length"] = self.t + cur_stats.get("ep_length", 0)

#         if not test_mode:
#             self.t_env += self.t

#         cur_returns.append(episode_return)

#         # --- log trigger behaviour metrics (episode-level) ---
#         if getattr(self, "_tm", None) is not None:
#             m = self._tm.summary()
#             rename = {"focus_max_mean": "focus_fire_mean", "kite_per_step": "kite_ratio"}
#             for k, v in list(m.items()):
#                 kk = rename.get(k, k)
#                 if test_mode:
#                     kk = "test_" + kk
#                 self.logger.log_stat(kk, v, self.t_env)

#         # --- log distance metrics (episode-level) ---
#         if getattr(self, "_dm", None) is not None:
#             dm = self._dm.summary()
#             for k, v in dm.items():
#                 kk = ("test_" + k) if test_mode else k
#                 self.logger.log_stat(kk, float(v), self.t_env)

#             # ===== DEBUG C: print dm summary for first 3 episodes =====
#             if self._dbg_enabled and self._dbg_dm_ep_print < 3:
#                 self._dbg_dm_ep_print += 1
#                 print("[DBG dm episode summary]", dm, "test_mode=", test_mode)

#         if test_mode and (len(self.test_returns) == self.args.test_nepisode):
#             self._log(cur_returns, cur_stats, log_prefix)
#         elif self.t_env - self.last_log_T >= self.args.log_interval:
#             self._log(cur_returns, cur_stats, log_prefix)

#         return self.batch

#     def _maybe_store_extra(self, ts: int):
#         """
#         If MAC provides get_last_extra(), write dict to EpisodeBatch
#         """
#         if not hasattr(self.mac, "get_last_extra"):
#             return
#         extra = self.mac.get_last_extra()
#         if not extra:
#             return

#         upd = {}
#         for k, v in extra.items():
#             upd[k] = v
#         try:
#             self.batch.update(upd, ts=ts)
#         except Exception:
#             # scheme mismatch -> ignore
#             pass

#     def _log(self, returns, stats, prefix):
#         # ===== DEBUG D: see if stats contains ally_* (would overwrite if we logged them) =====
#         if self._dbg_enabled and (not self._dbg_once_stats):
#             self._dbg_once_stats = True
#             for k in ["ally_dispersion", "ally_minsep", "ally_radius",
#                       "ally_dispersion_mean", "ally_minsep_mean", "ally_radius_mean"]:
#                 if k in stats:
#                     print("[DBG stats has]", k, "=", stats[k])

#         self.logger.log_stat(prefix + "return_mean", np.mean(returns), self.t_env)
#         self.logger.log_stat(prefix + "return_std", np.std(returns), self.t_env)
#         returns.clear()

#         # skip keys that collide with our custom metrics names
#         skip = {"ally_dispersion", "ally_minsep", "ally_radius",
#                 "ally_dispersion_mean", "ally_minsep_mean", "ally_radius_mean",
#                 "test_ally_dispersion_mean", "test_ally_minsep_mean", "test_ally_radius_mean"}

#         for k, v in stats.items():
#             if k != "n_episodes" and k not in skip:
#                 self.logger.log_stat(prefix + k + "_mean", v / stats["n_episodes"], self.t_env)

#         stats.clear()
#         self.last_log_T = self.t_env

#     def _debug_print_env_tree(self):
#         def show(obj, name):
#             if obj is None:
#                 print(f"[DBG ENV] {name}: None")
#                 return
#             attrs = [
#                 "_env", "env", "unwrapped",
#                 "agents", "allies", "ally_units", "allied_units",
#                 "n_agents", "get_state_dict", "get_state", "get_obs"
#             ]
#             found = {a: hasattr(obj, a) for a in attrs}
#             print(f"[DBG ENV] {name}: type={type(obj)} attrs={found}")

#         e0 = self.env
#         show(e0, "runner.env")

#         for a in ["_env", "env", "unwrapped"]:
#             if hasattr(e0, a) and getattr(e0, a) is not None:
#                 e1 = getattr(e0, a)
#                 show(e1, f"runner.env.{a}")

#                 for b in ["_env", "env", "unwrapped"]:
#                     if hasattr(e1, b) and getattr(e1, b) is not None:
#                         e2 = getattr(e1, b)
#                         show(e2, f"runner.env.{a}.{b}")

#     # --------------------------
#     # Coordinate extraction
#     # --------------------------
#     def _get_ally_pos_alive(self):
#         """
#         StarCraft2Env (SMAC) position extraction.

#         Returns:
#           ally_pos: np.ndarray [n_agents, 2] (x,y) in the same coordinate system as env units
#           ally_alive: np.ndarray [n_agents] bool
#         """
#         n_agents = self.env_info.get("n_agents", getattr(self.args, "n_agents", None))
#         if n_agents is None:
#             return None, None
#         n_agents = int(n_agents)

#         # --- Strategy 1: Use StarCraft2Env.agents (most reliable for SMAC) ---
#         if hasattr(self.env, "agents"):
#             try:
#                 units = getattr(self.env, "agents")
#                 if isinstance(units, (list, tuple)) and len(units) >= 1:
#                     pos = np.zeros((n_agents, 2), dtype=np.float32)
#                     alive = np.zeros((n_agents,), dtype=bool)

#                     # optional one-time debug to confirm unit structure
#                     if getattr(self, "_dbg_enabled", False) and not hasattr(self, "_dbg_unit_once"):
#                         self._dbg_unit_once = True
#                         u0 = units[0]
#                         print("[DBG unit0 type]", type(u0))
#                         if hasattr(u0, "pos"):
#                             print("[DBG unit0.pos type]", type(getattr(u0, "pos")))
#                             p0 = getattr(u0, "pos")
#                             if hasattr(p0, "x") and hasattr(p0, "y"):
#                                 print("[DBG unit0.pos.x/y]", float(p0.x), float(p0.y))
#                         for name in ["health", "health_max", "hp", "shield", "dead"]:
#                             if hasattr(u0, name):
#                                 try:
#                                     print(f"[DBG unit0.{name}]", getattr(u0, name))
#                                 except Exception:
#                                     pass

#                     for i in range(min(n_agents, len(units))):
#                         u = units[i]
#                         if u is None:
#                             alive[i] = False
#                             continue

#                         # position
#                         x = y = None
#                         if hasattr(u, "pos"):
#                             p = getattr(u, "pos")
#                             # pysc2 Point has .x .y
#                             if hasattr(p, "x") and hasattr(p, "y"):
#                                 x, y = float(p.x), float(p.y)
#                             else:
#                                 # sometimes pos can be tuple/list
#                                 try:
#                                     x, y = float(p[0]), float(p[1])
#                                 except Exception:
#                                     x = y = None
#                         if x is None or y is None:
#                             # fallback: direct x/y on unit
#                             if hasattr(u, "x") and hasattr(u, "y"):
#                                 try:
#                                     x, y = float(getattr(u, "x")), float(getattr(u, "y"))
#                                 except Exception:
#                                     x = y = None

#                         if x is None or y is None:
#                             # can't read pos -> leave zeros
#                             pass
#                         else:
#                             pos[i, 0] = x
#                             pos[i, 1] = y

#                         # alive (SMAC units usually have health)
#                         if hasattr(u, "health"):
#                             try:
#                                 alive[i] = float(getattr(u, "health")) > 0.0
#                             except Exception:
#                                 alive[i] = True
#                         elif hasattr(u, "hp"):
#                             try:
#                                 alive[i] = float(getattr(u, "hp")) > 0.0
#                             except Exception:
#                                 alive[i] = True
#                         elif hasattr(u, "dead"):
#                             try:
#                                 alive[i] = not bool(getattr(u, "dead"))
#                             except Exception:
#                                 alive[i] = True
#                         else:
#                             alive[i] = True

#                     return pos, alive
#             except Exception:
#                 pass

#         # --- Strategy 2 (optional): try get_state_dict for some SMAC forks ---
#         if hasattr(self.env, "get_state_dict"):
#             try:
#                 sd = self.env.get_state_dict()
#                 if getattr(self, "_dbg_enabled", False) and not hasattr(self, "_dbg_sd_once"):
#                     self._dbg_sd_once = True
#                     if isinstance(sd, dict):
#                         print("[DBG state_dict keys]", list(sd.keys())[:50])

#                 # some variants store allies as arrays
#                 if isinstance(sd, dict) and "allies" in sd:
#                     allies = sd["allies"]
#                     # Try common shapes: [n_agents, feat], where first two feats are x,y
#                     arr = np.asarray(allies)
#                     if arr.ndim == 2 and arr.shape[0] >= n_agents and arr.shape[1] >= 2:
#                         pos = arr[:n_agents, :2].astype(np.float32)
#                         # alive: health might be included as a later feature, but we can't assume -> mark all True
#                         alive = np.ones((n_agents,), dtype=bool)
#                         return pos, alive
#             except Exception:
#                 pass

#         return None, None
# src/runners/episode_runner.py
# from envs import REGISTRY as env_REGISTRY
# from functools import partial
# from components.episode_buffer import EpisodeBatch
# import numpy as np

# import torch as th
# from utils.trigger_metrics import TriggerMetrics
# from utils.distance_metrics import DistanceMetrics


# class EpisodeRunner:
#     def __init__(self, args, logger):
#         self.args = args
#         self.logger = logger
#         self.batch_size = self.args.batch_size_run
#         assert self.batch_size == 1

#         self.env = env_REGISTRY[self.args.env](**self.args.env_args)
#         self.episode_limit = self.env.episode_limit
#         self.t = 0

#         self.t_env = 0
#         self.last_log_T = 0

#         self.train_returns = []
#         self.test_returns = []
#         self.train_stats = {}
#         self.test_stats = {}

#         # --- env info ---
#         self.env_info = self.env.get_env_info()

#         # --- trigger behaviour metrics ---
#         _n_agents = self.env_info.get("n_agents", getattr(self.args, "n_agents", None))
#         _n_enemies = self.env_info.get("n_enemies", getattr(self.env, "n_enemies", 0) or 0)
#         _n_actions = self.env_info.get("n_actions", self.env_info.get("n_actions_total", 0))

#         if _n_agents is None or _n_enemies <= 0 or _n_actions <= 0:
#             self._tm = None
#         else:
#             self._tm = TriggerMetrics(
#                 n_agents=_n_agents,
#                 n_enemies=_n_enemies,
#                 n_actions_total=_n_actions,
#                 move_action_ids=getattr(self.args, "move_action_ids", None),
#             )

#         # --- distance metrics ---
#         if _n_agents is None:
#             self._dm = None
#         else:
#             self._dm = DistanceMetrics(n_agents=int(_n_agents))

#         # grid settings
#         self.grid_radius = int(getattr(self.args, "ally_grid_radius", 15))  # ±15 -> 31x31

#     def setup(self, scheme, groups, preprocess, mac):
#         self.new_batch = partial(
#             EpisodeBatch, scheme, groups, self.batch_size,
#             self.episode_limit + 1,
#             preprocess=preprocess,
#             device=self.args.device
#         )
#         self.mac = mac

#         if not hasattr(self, "env_info") or self.env_info is None:
#             self.env_info = self.env.get_env_info()

#     def get_env_info(self):
#         return self.env.get_env_info()

#     def save_replay(self):
#         self.env.save_replay()

#     def close_env(self):
#         self.env.close()

#     def reset(self):
#         self.batch = self.new_batch()
#         self.env.reset()
#         self.t = 0

#         if getattr(self, "_tm", None) is not None:
#             self._tm.reset()

#         if getattr(self, "_dm", None) is not None:
#             self._dm.reset()

#     def run(self, test_mode=False):
#         self.reset()

#         terminated = False
#         episode_return = 0
#         self.mac.init_hidden(batch_size=self.batch_size)

#         while not terminated:
#             # ---- build ally_grid at current timestep (pre-transition) ----
#             ally_grid = self._maybe_build_ally_grid()

#             pre_transition_data = {
#                 "state": [self.env.get_state()],
#                 "avail_actions": [self.env.get_avail_actions()],
#                 "obs": [self.env.get_obs()],
#             }

#             # only add ally_grid if scheme has it
#             if ally_grid is not None:
#                 pre_transition_data["ally_grid"] = [ally_grid]  # (n_agents,1,S,S)

#             self.batch.update(pre_transition_data, ts=self.t)

#             actions = self.mac.select_actions(
#                 self.batch, t_ep=self.t, t_env=self.t_env, test_mode=test_mode
#             )

#             reward, terminated, env_info = self.env.step(actions[0])
#             episode_return += reward

#             # --- trigger behaviour metrics ---
#             if getattr(self, "_tm", None) is not None:
#                 _tr = None
#                 if hasattr(self.mac, "get_last_extra"):
#                     try:
#                         _ex = self.mac.get_last_extra()
#                         _tr = _ex.get("triggers", None) if isinstance(_ex, dict) else None
#                     except Exception:
#                         _tr = None
#                 if _tr is None and hasattr(self.mac, "_last_triggers"):
#                     _tr = getattr(self.mac, "_last_triggers")
#                 self._tm.step(actions, float(reward), triggers=_tr)

#             # --- distance metrics ---
#             if getattr(self, "_dm", None) is not None:
#                 ally_pos, ally_alive = self._get_ally_pos_alive()
#                 self._dm.step(ally_pos, ally_alive)

#             post_transition_data = {
#                 "actions": actions,
#                 "reward": [(reward,)],
#                 "terminated": [(terminated != env_info.get("episode_limit", False),)],
#             }
#             self.batch.update(post_transition_data, ts=self.t)

#             # store triggers/msg etc extra into buffer if available
#             self._maybe_store_extra(ts=self.t)

#             self.t += 1

#         # last obs/state (+ last ally_grid)
#         ally_grid = self._maybe_build_ally_grid()
#         last_data = {
#             "state": [self.env.get_state()],
#             "avail_actions": [self.env.get_avail_actions()],
#             "obs": [self.env.get_obs()],
#         }
#         if ally_grid is not None:
#             last_data["ally_grid"] = [ally_grid]
#         self.batch.update(last_data, ts=self.t)

#         actions = self.mac.select_actions(
#             self.batch, t_ep=self.t, t_env=self.t_env, test_mode=test_mode
#         )
#         self.batch.update({"actions": actions}, ts=self.t)

#         self._maybe_store_extra(ts=self.t)

#         cur_stats = self.test_stats if test_mode else self.train_stats
#         cur_returns = self.test_returns if test_mode else self.train_returns
#         log_prefix = "test_" if test_mode else ""

#         cur_stats.update({k: cur_stats.get(k, 0) + env_info.get(k, 0) for k in env_info})
#         cur_stats["n_episodes"] = 1 + cur_stats.get("n_episodes", 0)
#         cur_stats["ep_length"] = self.t + cur_stats.get("ep_length", 0)

#         if not test_mode:
#             self.t_env += self.t

#         cur_returns.append(episode_return)

#         # --- log trigger behaviour metrics (episode-level) ---
#         if getattr(self, "_tm", None) is not None:
#             m = self._tm.summary()
#             rename = {"focus_max_mean": "focus_fire_mean", "kite_per_step": "kite_ratio"}
#             for k, v in list(m.items()):
#                 kk = rename.get(k, k)
#                 if test_mode:
#                     kk = "test_" + kk
#                 self.logger.log_stat(kk, v, self.t_env)

#         # --- log distance metrics (episode-level) ---
#         if getattr(self, "_dm", None) is not None:
#             dm = self._dm.summary()
#             for k, v in dm.items():
#                 kk = ("test_" + k) if test_mode else k
#                 self.logger.log_stat(kk, float(v), self.t_env)

#         if test_mode and (len(self.test_returns) == self.args.test_nepisode):
#             self._log(cur_returns, cur_stats, log_prefix)
#         elif self.t_env - self.last_log_T >= self.args.log_interval:
#             self._log(cur_returns, cur_stats, log_prefix)

#         return self.batch

#     def _maybe_store_extra(self, ts: int):
#         """
#         If MAC provides get_last_extra(), write dict to EpisodeBatch
#         """
#         if not hasattr(self.mac, "get_last_extra"):
#             return
#         extra = self.mac.get_last_extra()
#         if not extra:
#             return
#         try:
#             self.batch.update(extra, ts=ts)
#         except Exception:
#             # scheme mismatch -> ignore
#             pass

#     def _log(self, returns, stats, prefix):
#         self.logger.log_stat(prefix + "return_mean", np.mean(returns), self.t_env)
#         self.logger.log_stat(prefix + "return_std", np.std(returns), self.t_env)
#         returns.clear()

#         for k, v in stats.items():
#             if k != "n_episodes":
#                 self.logger.log_stat(prefix + k + "_mean", v / stats["n_episodes"], self.t_env)
#         stats.clear()
#         self.last_log_T = self.t_env

#     # --------------------------
#     # Ally position + alive (SMAC StarCraft2Env)
#     # --------------------------
#     def _get_ally_pos_alive(self):
#         n_agents = self.env_info.get("n_agents", getattr(self.args, "n_agents", None))
#         if n_agents is None:
#             return None, None
#         n_agents = int(n_agents)

#         if hasattr(self.env, "agents"):
#             units = getattr(self.env, "agents")
#             if isinstance(units, (list, tuple)) and len(units) >= 1:
#                 pos = np.zeros((n_agents, 2), dtype=np.float32)
#                 alive = np.zeros((n_agents,), dtype=bool)
#                 for i in range(min(n_agents, len(units))):
#                     u = units[i]
#                     if u is None:
#                         alive[i] = False
#                         continue

#                     x = y = None
#                     if hasattr(u, "pos"):
#                         p = getattr(u, "pos")
#                         if hasattr(p, "x") and hasattr(p, "y"):
#                             x, y = float(p.x), float(p.y)
#                         else:
#                             try:
#                                 x, y = float(p[0]), float(p[1])
#                             except Exception:
#                                 x = y = None
#                     if x is None or y is None:
#                         if hasattr(u, "x") and hasattr(u, "y"):
#                             try:
#                                 x, y = float(getattr(u, "x")), float(getattr(u, "y"))
#                             except Exception:
#                                 x = y = None
#                     if x is not None and y is not None:
#                         pos[i, 0] = x
#                         pos[i, 1] = y

#                     if hasattr(u, "health"):
#                         try:
#                             alive[i] = float(getattr(u, "health")) > 0.0
#                         except Exception:
#                             alive[i] = True
#                     elif hasattr(u, "hp"):
#                         try:
#                             alive[i] = float(getattr(u, "hp")) > 0.0
#                         except Exception:
#                             alive[i] = True
#                     elif hasattr(u, "dead"):
#                         try:
#                             alive[i] = not bool(getattr(u, "dead"))
#                         except Exception:
#                             alive[i] = True
#                     else:
#                         alive[i] = True

#                 return pos, alive

#         return None, None

#     # --------------------------
#     # Ally grid (±radius) around each agent
#     # --------------------------
#     def _maybe_build_ally_grid(self):
#         """
#         Build ally occupancy grid for each agent:
#           grid[i,0,dy+R,dx+R] = 1 if an alive ally j is within +/-R (excluding itself)
#         Returns:
#           np.ndarray (n_agents,1,2R+1,2R+1) or None if scheme doesn't include ally_grid.
#         """
#         if not hasattr(self, "batch") or not hasattr(self.batch, "scheme"):
#             return None
#         if "ally_grid" not in self.batch.scheme:
#             return None

#         ally_pos, ally_alive = self._get_ally_pos_alive()
#         n_agents = self.env_info.get("n_agents", getattr(self.args, "n_agents", 1))
#         n_agents = int(n_agents)
#         R = self.grid_radius
#         S = 2 * R + 1

#         if ally_pos is None or ally_alive is None:
#             return np.zeros((n_agents, 1, S, S), dtype=np.float32)

#         P = np.asarray(ally_pos, dtype=np.float32)
#         A = np.asarray(ally_alive).astype(bool)

#         grid = np.zeros((n_agents, 1, S, S), dtype=np.float32)
#         for i in range(n_agents):
#             if not A[i]:
#                 continue
#             xi, yi = P[i, 0], P[i, 1]
#             for j in range(n_agents):
#                 if j == i or (not A[j]):
#                     continue
#                 dx = int(np.rint(P[j, 0] - xi))
#                 dy = int(np.rint(P[j, 1] - yi))
#                 if abs(dx) <= R and abs(dy) <= R:
#                     grid[i, 0, dy + R, dx + R] = 1.0

#         return grid

from envs import REGISTRY as env_REGISTRY
from functools import partial
from components.episode_buffer import EpisodeBatch
import numpy as np

import torch as th
from utils.trigger_metrics import TriggerMetrics
from utils.distance_metrics import DistanceMetrics


class EpisodeRunner:
    def __init__(self, args, logger):
        self.args = args
        self.logger = logger
        self.batch_size = self.args.batch_size_run
        assert self.batch_size == 1

        self.env = env_REGISTRY[self.args.env](**self.args.env_args)
        self.episode_limit = self.env.episode_limit
        self.t = 0

        self.t_env = 0
        self.last_log_T = 0

        self.train_returns = []
        self.test_returns = []
        self.train_stats = {}
        self.test_stats = {}

        # --- env info ---
        self.env_info = self.env.get_env_info()

        # --- trigger behaviour metrics (focus fire / entropy / kiting / trigger rate) ---
        _n_agents = self.env_info.get("n_agents", getattr(self.args, "n_agents", None))
        _n_enemies = self.env_info.get("n_enemies", getattr(self.env, "n_enemies", 0) or 0)
        _n_actions = self.env_info.get("n_actions", self.env_info.get("n_actions_total", 0))

        if _n_agents is None or _n_enemies <= 0 or _n_actions <= 0:
            self._tm = None
        else:
            self._tm = TriggerMetrics(
                n_agents=_n_agents,
                n_enemies=_n_enemies,
                n_actions_total=_n_actions,
                move_action_ids=getattr(self.args, "move_action_ids", None),
            )

        # --- distance metrics (ally dispersion/minsep/radius) ---
        if _n_agents is None:
            self._dm = None
        else:
            self._dm = DistanceMetrics(n_agents=int(_n_agents))

        # debug control (optional)
        self._dbg_enabled = bool(getattr(self.args, "debug_metrics", True))  # 默认 True 方便你排查
        self._dbg_once_envinfo = False
        self._dbg_once_dm = False
        self._dbg_once_stats = False
        self._dbg_ep_count = 0
        self._dbg_dm_ep_print = 0

    def setup(self, scheme, groups, preprocess, mac):
        self.new_batch = partial(
            EpisodeBatch, scheme, groups, self.batch_size,
            self.episode_limit + 1,
            preprocess=preprocess,
            device=self.args.device
        )
        self.mac = mac

        if not hasattr(self, "env_info") or self.env_info is None:
            self.env_info = self.env.get_env_info()

    def get_env_info(self):
        return self.env.get_env_info()

    def save_replay(self):
        self.env.save_replay()

    def close_env(self):
        self.env.close()

    def reset(self):
        self.batch = self.new_batch()
        self.env.reset()
        self.t = 0

        if getattr(self, "_tm", None) is not None:
            self._tm.reset()

        if getattr(self, "_dm", None) is not None:
            self._dm.reset()

    def run(self, test_mode=False):
        self.reset()
        if not hasattr(self, "_dbg_env_tree_once"):
            self._dbg_env_tree_once = True
            self._debug_print_env_tree()

        terminated = False
        episode_return = 0
        self.mac.init_hidden(batch_size=self.batch_size)

        while not terminated:
            pre_transition_data = {
                "state": [self.env.get_state()],
                "avail_actions": [self.env.get_avail_actions()],
                "obs": [self.env.get_obs()]
            }
            self.batch.update(pre_transition_data, ts=self.t)

            actions = self.mac.select_actions(
                self.batch, t_ep=self.t, t_env=self.t_env, test_mode=test_mode
            )

            reward, terminated, env_info = self.env.step(actions[0])
            episode_return += reward

            # ===== DEBUG A: check env_info keys that may overwrite =====
            if self._dbg_enabled and (not self._dbg_once_envinfo):
                self._dbg_once_envinfo = True
                keys = [k for k in env_info.keys()
                        if ("ally_" in k) or ("disp" in k) or ("minsep" in k) or ("radius" in k)]
                print("[DBG env_info ally-related keys]", keys)
                for k in keys:
                    try:
                        print(f"[DBG env_info] {k}={env_info.get(k)}")
                    except Exception:
                        pass

            # ===== FIX: prevent env_info zeros overwriting our custom DistanceMetrics logs =====
            for _k in ["ally_dispersion", "ally_minsep", "ally_radius",
                       "ally_dispersion_mean", "ally_minsep_mean", "ally_radius_mean",
                       "test_ally_dispersion_mean", "test_ally_minsep_mean", "test_ally_radius_mean"]:
                if _k in env_info:
                    env_info.pop(_k, None)

            # --- trigger behaviour metrics ---
            if getattr(self, "_tm", None) is not None:
                _tr = None
                if hasattr(self.mac, "get_last_extra"):
                    try:
                        _ex = self.mac.get_last_extra()
                        _tr = _ex.get("triggers", None) if isinstance(_ex, dict) else None
                    except Exception:
                        _tr = None
                if _tr is None and hasattr(self.mac, "_last_triggers"):
                    _tr = getattr(self.mac, "_last_triggers")
                self._tm.step(actions, float(reward), triggers=_tr)

            # --- distance metrics (after env.step, before t++) ---
            if getattr(self, "_dm", None) is not None:
                ally_pos, ally_alive = self._get_ally_pos_alive()

                # ===== DEBUG B: check ally_pos/alive extraction (first 3 episodes only, at t=0) =====
                if self._dbg_enabled and self.t == 0 and self._dbg_ep_count < 3:
                    self._dbg_ep_count += 1
                    if ally_pos is None or ally_alive is None:
                        print("[DBG pos] ally_pos/alive is None")
                    else:
                        P = np.asarray(ally_pos)
                        A = np.asarray(ally_alive).astype(bool)
                        print("[DBG pos] P.shape=", P.shape, "alive_cnt=", int(A.sum()))
                        if P.size > 0:
                            print("[DBG pos] P_head=", P[:min(3, P.shape[0])])
                            print("[DBG pos] P_min=", float(P.min()), "P_max=", float(P.max()))
                            if np.allclose(P, 0):
                                print("[DBG pos] WARNING: positions are all zeros")
                            if int(A.sum()) >= 2:
                                Pa = P[A]
                                diff = Pa[:, None, :] - Pa[None, :, :]
                                D = np.sqrt((diff ** 2).sum(-1))
                                np.fill_diagonal(D, np.inf)
                                print("[DBG pos] pairwise_min=", float(D.min()),
                                      "pairwise_mean=", float(D[np.isfinite(D)].mean()))

                self._dm.step(ally_pos, ally_alive)

                # ===== DEBUG: check dm summary after first step of first episode =====
                if self._dbg_enabled and self.t == 0 and (not self._dbg_once_dm):
                    self._dbg_once_dm = True
                    print("[DBG dm summary after step0]", self._dm.summary())

            post_transition_data = {
                "actions": actions,
                "reward": [(reward,)],
                "terminated": [(terminated != env_info.get("episode_limit", False),)],
            }
            self.batch.update(post_transition_data, ts=self.t)
            if self.t == 0 and not hasattr(self, "_dbg_state_obs_once"):
                self._dbg_state_obs_once = True
                s = np.asarray(self.env.get_state())
                obs = self.env.get_obs()
                o0 = np.asarray(obs[0]) if isinstance(obs, (list, tuple)) and len(obs) > 0 else None
                print("[DBG SO] state_shape:", s.shape, "state_head:", s[:40])
                if o0 is not None:
                    print("[DBG SO] obs0_shape:", o0.shape, "obs0_head:", o0[:40])
                else:
                    print("[DBG SO] obs0: None")


            # store triggers/msg etc extra into buffer if available
            self._maybe_store_extra(ts=self.t)

            self.t += 1

        # last obs/state
        last_data = {
            "state": [self.env.get_state()],
            "avail_actions": [self.env.get_avail_actions()],
            "obs": [self.env.get_obs()]
        }
        self.batch.update(last_data, ts=self.t)

        actions = self.mac.select_actions(
            self.batch, t_ep=self.t, t_env=self.t_env, test_mode=test_mode
        )
        self.batch.update({"actions": actions}, ts=self.t)

        # store extra at terminal
        self._maybe_store_extra(ts=self.t)

        cur_stats = self.test_stats if test_mode else self.train_stats
        cur_returns = self.test_returns if test_mode else self.train_returns
        log_prefix = "test_" if test_mode else ""

        cur_stats.update({k: cur_stats.get(k, 0) + env_info.get(k, 0) for k in env_info})
        cur_stats["n_episodes"] = 1 + cur_stats.get("n_episodes", 0)
        cur_stats["ep_length"] = self.t + cur_stats.get("ep_length", 0)

        if not test_mode:
            self.t_env += self.t

        cur_returns.append(episode_return)

        # --- log trigger behaviour metrics (episode-level) ---
        if getattr(self, "_tm", None) is not None:
            m = self._tm.summary()
            rename = {"focus_max_mean": "focus_fire_mean", "kite_per_step": "kite_ratio"}
            for k, v in list(m.items()):
                kk = rename.get(k, k)
                if test_mode:
                    kk = "test_" + kk
                self.logger.log_stat(kk, v, self.t_env)

        # --- log distance metrics (episode-level) ---
        if getattr(self, "_dm", None) is not None:
            dm = self._dm.summary()
            for k, v in dm.items():
                kk = ("test_" + k) if test_mode else k
                self.logger.log_stat(kk, float(v), self.t_env)

            # ===== DEBUG C: print dm summary for first 3 episodes =====
            if self._dbg_enabled and self._dbg_dm_ep_print < 3:
                self._dbg_dm_ep_print += 1
                print("[DBG dm episode summary]", dm, "test_mode=", test_mode)

        if test_mode and (len(self.test_returns) == self.args.test_nepisode):
            self._log(cur_returns, cur_stats, log_prefix)
        elif self.t_env - self.last_log_T >= self.args.log_interval:
            self._log(cur_returns, cur_stats, log_prefix)

        return self.batch

    def _maybe_store_extra(self, ts: int):
        """
        If MAC provides get_last_extra(), write dict to EpisodeBatch
        """
        if not hasattr(self.mac, "get_last_extra"):
            return
        extra = self.mac.get_last_extra()
        if not extra:
            return

        upd = {}
        for k, v in extra.items():
            upd[k] = v
        try:
            self.batch.update(upd, ts=ts)
        except Exception:
            # scheme mismatch -> ignore
            pass

    def _log(self, returns, stats, prefix):
        # ===== DEBUG D: see if stats contains ally_* (would overwrite if we logged them) =====
        if self._dbg_enabled and (not self._dbg_once_stats):
            self._dbg_once_stats = True
            for k in ["ally_dispersion", "ally_minsep", "ally_radius",
                      "ally_dispersion_mean", "ally_minsep_mean", "ally_radius_mean"]:
                if k in stats:
                    print("[DBG stats has]", k, "=", stats[k])

        self.logger.log_stat(prefix + "return_mean", np.mean(returns), self.t_env)
        self.logger.log_stat(prefix + "return_std", np.std(returns), self.t_env)
        returns.clear()

        # skip keys that collide with our custom metrics names
        skip = {"ally_dispersion", "ally_minsep", "ally_radius",
                "ally_dispersion_mean", "ally_minsep_mean", "ally_radius_mean",
                "test_ally_dispersion_mean", "test_ally_minsep_mean", "test_ally_radius_mean"}

        for k, v in stats.items():
            if k != "n_episodes" and k not in skip:
                self.logger.log_stat(prefix + k + "_mean", v / stats["n_episodes"], self.t_env)

        stats.clear()
        self.last_log_T = self.t_env

    def _debug_print_env_tree(self):
        def show(obj, name):
            if obj is None:
                print(f"[DBG ENV] {name}: None")
                return
            attrs = [
                "_env", "env", "unwrapped",
                "agents", "allies", "ally_units", "allied_units",
                "n_agents", "get_state_dict", "get_state", "get_obs"
            ]
            found = {a: hasattr(obj, a) for a in attrs}
            print(f"[DBG ENV] {name}: type={type(obj)} attrs={found}")

        e0 = self.env
        show(e0, "runner.env")

        for a in ["_env", "env", "unwrapped"]:
            if hasattr(e0, a) and getattr(e0, a) is not None:
                e1 = getattr(e0, a)
                show(e1, f"runner.env.{a}")

                for b in ["_env", "env", "unwrapped"]:
                    if hasattr(e1, b) and getattr(e1, b) is not None:
                        e2 = getattr(e1, b)
                        show(e2, f"runner.env.{a}.{b}")

    # --------------------------
    # Coordinate extraction
    # --------------------------
    def _get_ally_pos_alive(self):
        """
        StarCraft2Env (SMAC) position extraction.

        Returns:
          ally_pos: np.ndarray [n_agents, 2] (x,y) in the same coordinate system as env units
          ally_alive: np.ndarray [n_agents] bool
        """
        n_agents = self.env_info.get("n_agents", getattr(self.args, "n_agents", None))
        if n_agents is None:
            return None, None
        n_agents = int(n_agents)

        # --- Strategy 1: Use StarCraft2Env.agents (most reliable for SMAC) ---
        if hasattr(self.env, "agents"):
            try:
                units = getattr(self.env, "agents")
                if isinstance(units, (list, tuple)) and len(units) >= 1:
                    pos = np.zeros((n_agents, 2), dtype=np.float32)
                    alive = np.zeros((n_agents,), dtype=bool)

                    # optional one-time debug to confirm unit structure
                    if getattr(self, "_dbg_enabled", False) and not hasattr(self, "_dbg_unit_once"):
                        self._dbg_unit_once = True
                        u0 = units[0]
                        print("[DBG unit0 type]", type(u0))
                        if hasattr(u0, "pos"):
                            print("[DBG unit0.pos type]", type(getattr(u0, "pos")))
                            p0 = getattr(u0, "pos")
                            if hasattr(p0, "x") and hasattr(p0, "y"):
                                print("[DBG unit0.pos.x/y]", float(p0.x), float(p0.y))
                        for name in ["health", "health_max", "hp", "shield", "dead"]:
                            if hasattr(u0, name):
                                try:
                                    print(f"[DBG unit0.{name}]", getattr(u0, name))
                                except Exception:
                                    pass

                    for i in range(min(n_agents, len(units))):
                        u = units[i]
                        if u is None:
                            alive[i] = False
                            continue

                        # position
                        x = y = None
                        if hasattr(u, "pos"):
                            p = getattr(u, "pos")
                            # pysc2 Point has .x .y
                            if hasattr(p, "x") and hasattr(p, "y"):
                                x, y = float(p.x), float(p.y)
                            else:
                                # sometimes pos can be tuple/list
                                try:
                                    x, y = float(p[0]), float(p[1])
                                except Exception:
                                    x = y = None
                        if x is None or y is None:
                            # fallback: direct x/y on unit
                            if hasattr(u, "x") and hasattr(u, "y"):
                                try:
                                    x, y = float(getattr(u, "x")), float(getattr(u, "y"))
                                except Exception:
                                    x = y = None

                        if x is None or y is None:
                            # can't read pos -> leave zeros
                            pass
                        else:
                            pos[i, 0] = x
                            pos[i, 1] = y

                        # alive (SMAC units usually have health)
                        if hasattr(u, "health"):
                            try:
                                alive[i] = float(getattr(u, "health")) > 0.0
                            except Exception:
                                alive[i] = True
                        elif hasattr(u, "hp"):
                            try:
                                alive[i] = float(getattr(u, "hp")) > 0.0
                            except Exception:
                                alive[i] = True
                        elif hasattr(u, "dead"):
                            try:
                                alive[i] = not bool(getattr(u, "dead"))
                            except Exception:
                                alive[i] = True
                        else:
                            alive[i] = True

                    return pos, alive
            except Exception:
                pass

        # --- Strategy 2 (optional): try get_state_dict for some SMAC forks ---
        if hasattr(self.env, "get_state_dict"):
            try:
                sd = self.env.get_state_dict()
                if getattr(self, "_dbg_enabled", False) and not hasattr(self, "_dbg_sd_once"):
                    self._dbg_sd_once = True
                    if isinstance(sd, dict):
                        print("[DBG state_dict keys]", list(sd.keys())[:50])

                # some variants store allies as arrays
                if isinstance(sd, dict) and "allies" in sd:
                    allies = sd["allies"]
                    # Try common shapes: [n_agents, feat], where first two feats are x,y
                    arr = np.asarray(allies)
                    if arr.ndim == 2 and arr.shape[0] >= n_agents and arr.shape[1] >= 2:
                        pos = arr[:n_agents, :2].astype(np.float32)
                        # alive: health might be included as a later feature, but we can't assume -> mark all True
                        alive = np.ones((n_agents,), dtype=bool)
                        return pos, alive
            except Exception:
                pass

        return None, None





