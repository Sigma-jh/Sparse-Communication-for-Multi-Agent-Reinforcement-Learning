# -*- coding: utf-8 -*-
from __future__ import annotations
import torch as th

from modules.qdt_vision import QLConfig, QLearningModule


class QDTVisionLearner:
    def __init__(self, mac, scheme, logger, args):
        self.mac = mac
        self.logger = logger
        self.args = args
        self.device = th.device(args.device)

        self.q_module = None
        self.optim = th.optim.Adam(self.mac.parameters(), lr=getattr(args, "lr", 3e-4))

        self.grad_norm_clip = getattr(args, "grad_norm_clip", 10.0)
        self.lambda_comm = getattr(args, "lambda_comm", 0.02)
        self.lambda_qdt = getattr(args, "lambda_qdt", 1.0)
        self.normalize_adv = getattr(args, "normalize_adv", True)
        self.adv_clip = getattr(args, "adv_clip", None)

    def cuda(self):
        if hasattr(self.mac, "cuda"):
            self.mac.cuda()
        self.device = th.device("cuda")

    @th.no_grad()
    def _mc_returns(self, rewards_t, dones_t, gamma: float):
        T, bs = rewards_t.shape[0], rewards_t.shape[1]
        G = th.zeros(T, bs, device=rewards_t.device)
        running = th.zeros(bs, device=rewards_t.device)
        for t in reversed(range(T)):
            r = rewards_t[t, :, 0]
            d = dones_t[t, :, 0].float()
            running = r + gamma * running * (1.0 - d)
            G[t] = running
        return G  # [T, bs]

    def _ensure_qmodule(self, state_aug_dim: int):
        if self.q_module is None:
            q_cfg = QLConfig(
                state_dim=state_aug_dim,
                lr=getattr(self.args, "lr", 3e-4),
                gamma=getattr(self.args, "gamma", 0.99),
            )
            self.q_module = QLearningModule(q_cfg)
            if hasattr(self.q_module, "to"):
                self.q_module.to(self.device)

    def train(self, batch, t_env: int, episode_num: int):
        device = self.device
        T = batch.max_seq_length - 1
        bs = batch.batch_size
        A = self.args.n_agents

        rewards = batch["reward"][:, :T].to(device)          # [bs, T, 1]
        dones = batch["terminated"][:, :T].to(device)        # [bs, T, 1]
        actions = batch["actions"][:, :T].to(device).long()  # [bs, T, A, 1]
        probs = batch["probs"][:, :T].to(device)             # [bs, T, A, n_actions]
        triggers = batch["triggers"][:, :T].to(device)       # [bs, T, A, 1]
        z = batch["z"][:, :T].to(device)                     # [bs, T, A, d]
        state_aug = batch["state_aug"][:, :T].to(device)     # [bs, T, S_aug]

        # time-major
        rewards_t = rewards.transpose(0, 1).contiguous()
        dones_t = dones.transpose(0, 1).contiguous()
        actions_t = actions.transpose(0, 1).contiguous()
        probs_t = probs.transpose(0, 1).contiguous()
        triggers_t = triggers.transpose(0, 1).contiguous()
        z_t = z.transpose(0, 1).contiguous()
        state_aug_t = state_aug.transpose(0, 1).contiguous()

        gamma = getattr(self.args, "gamma", 0.99)
        with th.no_grad():
            G = self._mc_returns(rewards_t, dones_t, gamma)   # [T, bs]

        # teacher critic update
        S_aug = int(state_aug_t.shape[-1])
        self._ensure_qmodule(S_aug)

        q_losses = []
        V_targets = []
        for b in range(bs):
            q_loss_b, V_target_b = self.q_module.update(
                state_aug=state_aug_t[:, b, :],
                rewards=rewards_t[:, b, 0],
                dones=dones_t[:, b, 0].float(),
            )
            q_losses.append(q_loss_b)
            V_targets.append(V_target_b)

        q_loss = th.stack(q_losses).mean()
        V_target = th.stack(V_targets, dim=1)                # [T, bs]

        R_teacher = V_target.unsqueeze(-1).expand(T, bs, A)   # [T, bs, A]
        R_qdt = self.mac.qdt.value_head(z_t).squeeze(-1)      # [T, bs, A]

        adv = G.unsqueeze(-1).expand(T, bs, A)  # [T, bs, A]

        # time-wise baseline: mean over batch at each t (最简单稳)
        baseline = adv.mean(dim=1, keepdim=True)  # [T, 1, A]
        adv = adv - baseline

        if self.normalize_adv:
            adv = (adv - adv.mean()) / (adv.std(unbiased=False) + 1e-8)

        if self.adv_clip is not None:
            adv = adv.clamp(-float(self.adv_clip), float(self.adv_clip))

        adv = adv.detach()


        probs_a = th.gather(probs_t, dim=-1, index=actions_t).squeeze(-1)  # [T, bs, A]
        log_pi = th.log(probs_a.clamp_min(1e-12))
        L_action = -(adv * log_pi).mean()

        L_comm = triggers_t.mean()
        L_qdt = ((R_teacher - R_qdt) ** 2).mean()

        total_loss = L_action + self.lambda_comm * L_comm + self.lambda_qdt * L_qdt

        self.optim.zero_grad(set_to_none=True)
        total_loss.backward()
        grad_norm = th.nn.utils.clip_grad_norm_(list(self.mac.parameters()), self.grad_norm_clip)
        self.optim.step()

        # log
        self.logger.log_stat("loss_total", float(total_loss.detach().cpu()), t_env)
        self.logger.log_stat("L_action", float(L_action.detach().cpu()), t_env)
        self.logger.log_stat("L_comm", float(L_comm.detach().cpu()), t_env)
        self.logger.log_stat("L_qdt", float(L_qdt.detach().cpu()), t_env)
        self.logger.log_stat("q_loss", float(q_loss.detach().cpu()), t_env)
        self.logger.log_stat("grad_norm", float(grad_norm.detach().cpu()) if hasattr(grad_norm, "detach") else float(grad_norm), t_env)
        self.logger.log_stat("trigger_rate", float(L_comm.detach().cpu()), t_env)

    def save_models(self, path):
        self.mac.save_models(path)

    def load_models(self, path):
        self.mac.load_models(path)
