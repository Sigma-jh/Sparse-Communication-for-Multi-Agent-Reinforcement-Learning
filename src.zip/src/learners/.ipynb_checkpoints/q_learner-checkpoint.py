# src/learners/q_learner.py
import copy
from components.episode_buffer import EpisodeBatch
from modules.mixers.qmix import QMixer
import torch as th
from torch.optim import RMSprop


class QLearner:
    def __init__(self, mac, scheme, logger, args):
        self.args = args
        self.mac = mac
        self.logger = logger

        self.params = list(mac.parameters())

        self.mixer = None
        if args.mixer is not None:
            if args.mixer == "qmix":
                self.mixer = QMixer(args)
            else:
                raise ValueError("Mixer {} not recognised.".format(args.mixer))
            self.params += list(self.mixer.parameters())
            self.target_mixer = copy.deepcopy(self.mixer)

        self.optimiser = RMSprop(params=self.params, lr=args.lr, alpha=args.optim_alpha, eps=args.optim_eps)

        self.target_mac = copy.deepcopy(mac)

        self.last_target_update_episode = 0
        self.log_stats_t = -self.args.learner_log_interval - 1

        self.lambda_comm = float(getattr(args, "lambda_comm", 0.0))

    def train(self, batch: EpisodeBatch, t_env: int, episode_num: int):
        # ----- masks / rewards -----
        rewards = batch["reward"][:, :-1]
        actions = batch["actions"][:, :-1]
        terminated = batch["terminated"][:, :-1].float()
        mask = batch["filled"][:, :-1].float()
        mask[:, 1:] = mask[:, 1:] * (1 - terminated[:, :-1])

        # ----- run mac over time to get Q and triggers (WITH grad) -----
        mac_out = []
        trig_out = []
        self.mac.init_hidden(batch.batch_size)
        for t in range(batch.max_seq_length):
            agent_outs = self.mac.forward(batch, t=t)  # [bs, A, n_actions]
            mac_out.append(agent_outs)

            if hasattr(self.mac, "get_last_triggers"):
                tr = self.mac.get_last_triggers()
                if tr is None:
                    tr = th.zeros(batch.batch_size, self.args.n_agents, 1, device=batch.device)
            else:
                tr = th.zeros(batch.batch_size, self.args.n_agents, 1, device=batch.device)

            trig_out.append(tr)

        mac_out = th.stack(mac_out, dim=1)   # [bs, T, A, n_actions]
        trig_out = th.stack(trig_out, dim=1) # [bs, T, A, 1]

        # ----- chosen action qvals -----
        chosen_action_qvals = th.gather(mac_out[:, :-1], dim=3, index=actions).squeeze(3)  # [bs, T-1, A]

        # ----- target mac -----
        target_mac_out = []
        self.target_mac.init_hidden(batch.batch_size)
        for t in range(batch.max_seq_length):
            target_agent_outs = self.target_mac.forward(batch, t=t)
            target_mac_out.append(target_agent_outs)
        target_mac_out = th.stack(target_mac_out, dim=1)  # [bs, T, A, n_actions]

        # mask unavailable actions for target
        avail_actions = batch["avail_actions"]
        target_mac_out[avail_actions == 0] = -9999999

        # ----- Double Q -----
        if getattr(self.args, "double_q", True):
            mac_out_detach = mac_out.clone().detach()
            mac_out_detach[avail_actions == 0] = -9999999
            cur_max_actions = mac_out_detach[:, 1:].max(dim=3, keepdim=True)[1]
            target_max_qvals = th.gather(target_mac_out[:, 1:], 3, cur_max_actions).squeeze(3)
        else:
            target_max_qvals = target_mac_out[:, 1:].max(dim=3)[0]

        # ----- Mix -----
        if self.mixer is not None:
            chosen_action_qvals = self.mixer(chosen_action_qvals, batch["state"][:, :-1])
            target_max_qvals = self.target_mixer(target_max_qvals, batch["state"][:, 1:])

        # ----- TD targets -----
        targets = rewards + self.args.gamma * (1 - terminated) * target_max_qvals.detach()

        # ----- TD error -----
        td_error = (chosen_action_qvals - targets)
        mask = mask.expand_as(td_error)
        masked_td_error = td_error * mask

        # ----- losses -----
        q_loss = (masked_td_error ** 2).sum() / mask.sum().clamp(min=1.0)

        # comm cost: mean trigger (use t< T-1)
        L_comm = trig_out[:, :-1].float().mean()
        loss_total = q_loss + self.lambda_comm * L_comm

        # ----- optimise -----
        self.optimiser.zero_grad()
        loss_total.backward()
        grad_norm = th.nn.utils.clip_grad_norm_(self.params, self.args.grad_norm_clip)
        self.optimiser.step()

        # ----- target update -----
        if (episode_num - self.last_target_update_episode) / self.args.target_update_interval >= 1.0:
            self._update_targets()
            self.last_target_update_episode = episode_num

        # ----- logging -----
        if t_env - self.log_stats_t >= self.args.learner_log_interval:
            mask_elems = mask.sum().item()
            trigger_rate = float(trig_out[:, :-1].detach().float().mean().item())

            self.logger.log_stat("loss", loss_total.item(), t_env)
            self.logger.log_stat("loss_total", loss_total.item(), t_env)
            self.logger.log_stat("q_loss", q_loss.item(), t_env)
            self.logger.log_stat("L_comm", float(L_comm.detach().item()), t_env)
            self.logger.log_stat("trigger_rate", trigger_rate, t_env)

            self.logger.log_stat("grad_norm", grad_norm, t_env)
            self.logger.log_stat("td_error_abs", (masked_td_error.abs().sum().item() / max(mask_elems, 1.0)), t_env)
            self.logger.log_stat("q_taken_mean", (chosen_action_qvals * mask).sum().item() / (max(mask_elems, 1.0) * self.args.n_agents), t_env)
            self.logger.log_stat("target_mean", (targets * mask).sum().item() / (max(mask_elems, 1.0) * self.args.n_agents), t_env)

            self.log_stats_t = t_env

    def _update_targets(self):
        self.target_mac.load_state(self.mac)
        if self.mixer is not None:
            self.target_mixer.load_state_dict(self.mixer.state_dict())
        self.logger.console_logger.info("Updated target network")

    def cuda(self):
        self.mac.cuda()
        self.target_mac.cuda()
        if self.mixer is not None:
            self.mixer.cuda()
            self.target_mixer.cuda()

    def save_models(self, path):
        self.mac.save_models(path)
        if self.mixer is not None:
            th.save(self.mixer.state_dict(), "{}/mixer.th".format(path))
        th.save(self.optimiser.state_dict(), "{}/opt.th".format(path))

    def load_models(self, path):
        self.mac.load_models(path)
        self.target_mac.load_models(path)
        if self.mixer is not None:
            self.mixer.load_state_dict(th.load("{}/mixer.th".format(path), map_location=lambda storage, loc: storage))
            self.target_mixer.load_state_dict(self.mixer.state_dict())
        self.optimiser.load_state_dict(th.load("{}/opt.th".format(path), map_location=lambda storage, loc: storage))
