from .q_learner import QLearner
from .coma_learner import COMALearner
from .qtran_learner import QLearner as QTranLearner

REGISTRY = {}

REGISTRY["q_learner"] = QLearner
REGISTRY["coma_learner"] = COMALearner
REGISTRY["qtran_learner"] = QTranLearner
from .qdt_vision_learner import QDTVisionLearner
REGISTRY["qdt_vision_learner"] = QDTVisionLearner


from .ppo_learner import PPOLearner


REGISTRY["ppo_learner"] = PPOLearner
