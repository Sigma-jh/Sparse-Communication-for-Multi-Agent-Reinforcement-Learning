import torch as th
import torch.nn as nn
from torch.optim import Adam

from components.episode_buffer import EpisodeBatch
from modules.critics import REGISTRY as critic_REGISTRY


class PPOLearner:
    def __init__(self, mac, scheme, logger, args):
        self.args = args
        self.mac = mac
        self.logger = logger

        self.critic = critic_REGISTRY[args.critic_type](scheme, args)

        self.agent_params = list(mac.parameters())
        self.critic_params = list(self.critic.parameters())
        self.params = self.agent_params + self.critic_params

        self.optimiser = Adam(self.params, lr=args.lr)

        self.log_stats_t = -self.args.learner_log_interval - 1

    def train(self, batch: EpisodeBatch, t_env: int, episode_num: int):
        rewards = batch["reward"][:, :-1]                # [bs, T, 1]
        actions = batch["actions"][:, :-1]               # [bs, T, n_agents, 1]
        terminated = batch["terminated"][:, :-1].float() # [bs, T, 1]
        filled = batch["filled"][:, :-1].float()         # [bs, T, 1]
        states = batch["state"]                          # [bs, T+1, state_dim]

        mask = filled.clone()
        mask[:, 1:] = mask[:, 1:] * (1 - terminated[:, :-1])
        agent_mask = mask.expand(-1, -1, self.args.n_agents)  # [bs, T, n_agents]

        # ---------- old policy ----------
        with th.no_grad():
            old_probs = []
            self.mac.init_hidden(batch.batch_size)
            for t in range(batch.max_seq_length - 1):
                pi = self.mac.forward(batch, t=t, test_mode=False)  # [bs, n_agents, n_actions]
                old_probs.append(pi)
            old_probs = th.stack(old_probs, dim=1)  # [bs, T, n_agents, n_actions]

            old_action_probs = th.gather(old_probs, dim=3, index=actions).squeeze(3)
            old_action_probs = th.clamp(old_action_probs, min=1e-10)
            old_log_probs = th.log(old_action_probs)  # [bs, T, n_agents]

            values = self.critic(states[:, :-1]).squeeze(-1)   # [bs, T, n_agents]
            next_values = self.critic(states[:, 1:]).squeeze(-1)

            rewards_expand = rewards.expand(-1, -1, self.args.n_agents)
            terminated_expand = terminated.expand(-1, -1, self.args.n_agents)

            advantages = th.zeros_like(values)
            gae = th.zeros_like(values[:, 0])

            for t in reversed(range(values.shape[1])):
                delta = rewards_expand[:, t] + self.args.gamma * next_values[:, t] * (1 - terminated_expand[:, t]) - values[:, t]
                gae = delta + self.args.gamma * self.args.gae_lambda * (1 - terminated_expand[:, t]) * gae
                advantages[:, t] = gae

            returns = advantages + values

            if getattr(self.args, "norm_adv", True):
                adv_mean = advantages[agent_mask > 0].mean()
                adv_std = advantages[agent_mask > 0].std() + 1e-8
                advantages = (advantages - adv_mean) / adv_std

        total_actor_loss = 0.0
        total_critic_loss = 0.0
        total_entropy = 0.0

        for _ in range(self.args.ppo_epochs):
            new_probs = []
            self.mac.init_hidden(batch.batch_size)
            for t in range(batch.max_seq_length - 1):
                pi = self.mac.forward(batch, t=t, test_mode=False)
                new_probs.append(pi)
            new_probs = th.stack(new_probs, dim=1)  # [bs, T, n_agents, n_actions]

            new_action_probs = th.gather(new_probs, dim=3, index=actions).squeeze(3)
            new_action_probs = th.clamp(new_action_probs, min=1e-10)
            new_log_probs = th.log(new_action_probs)

            entropy = -(new_probs * th.log(th.clamp(new_probs, min=1e-10))).sum(dim=-1)  # [bs, T, n_agents]

            new_values = self.critic(states[:, :-1]).squeeze(-1)

            ratio = th.exp(new_log_probs - old_log_probs)
            surr1 = ratio * advantages
            surr2 = th.clamp(ratio, 1.0 - self.args.clip_param, 1.0 + self.args.clip_param) * advantages

            actor_loss = -(th.min(surr1, surr2) * agent_mask).sum() / agent_mask.sum()
            critic_loss = (((new_values - returns) ** 2) * agent_mask).sum() / agent_mask.sum()
            entropy_loss = (entropy * agent_mask).sum() / agent_mask.sum()

            loss = actor_loss + self.args.value_loss_coef * critic_loss - self.args.entropy_coef * entropy_loss

            self.optimiser.zero_grad()
            loss.backward()
            grad_norm = nn.utils.clip_grad_norm_(self.params, self.args.grad_norm_clip)
            self.optimiser.step()

            total_actor_loss += actor_loss.item()
            total_critic_loss += critic_loss.item()
            total_entropy += entropy_loss.item()

        if t_env - self.log_stats_t >= self.args.learner_log_interval:
            self.logger.log_stat("ppo_actor_loss", total_actor_loss / self.args.ppo_epochs, t_env)
            self.logger.log_stat("ppo_critic_loss", total_critic_loss / self.args.ppo_epochs, t_env)
            self.logger.log_stat("ppo_entropy", total_entropy / self.args.ppo_epochs, t_env)
            self.logger.log_stat("ppo_grad_norm", grad_norm, t_env)
            self.log_stats_t = t_env

    def cuda(self):
        self.mac.cuda()
        self.critic.cuda()

    def save_models(self, path):
        self.mac.save_models(path)
        th.save(self.critic.state_dict(), "{}/critic.th".format(path))
        th.save(self.optimiser.state_dict(), "{}/opt.th".format(path))

    def load_models(self, path):
        self.mac.load_models(path)
        self.critic.load_state_dict(th.load("{}/critic.th".format(path), map_location=lambda storage, loc: storage))
        self.optimiser.load_state_dict(th.load("{}/opt.th".format(path), map_location=lambda storage, loc: storage))
