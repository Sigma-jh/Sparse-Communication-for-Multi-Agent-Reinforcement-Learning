import torch as th
import torch.nn as nn
import torch.nn.functional as F


class RNNPolicyAgent(nn.Module):
    def __init__(self, input_shape, args):
        super(RNNPolicyAgent, self).__init__()
        self.args = args

        self.fc1 = nn.Linear(input_shape, args.rnn_hidden_dim)
        self.rnn = nn.GRUCell(args.rnn_hidden_dim, args.rnn_hidden_dim)
        self.fc_pi = nn.Linear(args.rnn_hidden_dim, args.n_actions)

    def init_hidden(self):
        # shape: [1, hidden_dim]
        return self.fc1.weight.new(1, self.args.rnn_hidden_dim).zero_()

    def forward(self, inputs, hidden_state):
        """
        inputs: [bs*n_agents, input_dim]
        hidden_state: [bs*n_agents, hidden_dim]
        """
        x = F.relu(self.fc1(inputs), inplace=True)
        h_in = hidden_state.reshape(-1, self.args.rnn_hidden_dim)
        h = self.rnn(x, h_in)
        logits = self.fc_pi(h)
        return logits, h
