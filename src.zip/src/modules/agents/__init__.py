REGISTRY = {}

from .rnn_agent import RNNAgent
from .rnn_policy_agent import RNNPolicyAgent

REGISTRY["rnn"] = RNNAgent
REGISTRY["rnn_policy"] = RNNPolicyAgent
