import torch as th
import torch.nn as nn
import torch.nn.functional as F


class CentralVCritic(nn.Module):
    def __init__(self, scheme, args):
        super(CentralVCritic, self).__init__()
        self.args = args
        self.n_agents = args.n_agents

        state_shape = scheme["state"]["vshape"]
        input_dim = state_shape + self.n_agents

        self.fc1 = nn.Linear(input_dim, args.critic_hidden_dim)
        self.fc2 = nn.Linear(args.critic_hidden_dim, args.critic_hidden_dim)
        self.fc_v = nn.Linear(args.critic_hidden_dim, 1)

    def forward(self, states):
        """
        states: [bs, t, state_dim]
        return: [bs, t, n_agents, 1]
        """
        bs, ts, state_dim = states.shape

        states = states.unsqueeze(2).expand(bs, ts, self.n_agents, state_dim)

        agent_ids = th.eye(self.n_agents, device=states.device).view(1, 1, self.n_agents, self.n_agents)
        agent_ids = agent_ids.expand(bs, ts, self.n_agents, self.n_agents)

        x = th.cat([states, agent_ids], dim=-1)
        x = F.relu(self.fc1(x), inplace=True)
        x = F.relu(self.fc2(x), inplace=True)
        v = self.fc_v(x)
        return v
