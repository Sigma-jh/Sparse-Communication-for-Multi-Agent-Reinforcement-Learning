REGISTRY = {}

from .central_v_critic import CentralVCritic

REGISTRY["central_v"] = CentralVCritic
