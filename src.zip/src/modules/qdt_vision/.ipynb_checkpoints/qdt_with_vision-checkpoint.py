# qdt_with_vision.py
# -*- coding: utf-8 -*-
"""
QDT Controller + VisionSignalProcessor + Q-learning 整合版（无 MAPPO 依赖）

依赖：
    from patched_vision_signal import VisionSignalProcessor, VisionConfig
    from qlearning_full import QLearningModule
"""

from dataclasses import dataclass
from typing import Dict, Any, List, Optional

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions import Categorical

from .patched_vision_signal import VisionSignalProcessor, VisionConfig


Device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


# ================= 邻居注意力通信 =================

class NeighborComm(nn.Module):
    """
    N(i) 来自邻接矩阵 neighbor_mask
    实际参与通信的是：j ∈ N(i) 且 trigger_j^t = 1
    α_{i,j} = attention(h_i, h_j)
    m_i^t   = Σ_j α_{i,j} * h_j
    """

    def __init__(self, hidden_dim: int):
        super().__init__()
        d = hidden_dim
        self.att_mlp = nn.Sequential(
            nn.Linear(2 * d, d),
            nn.ReLU(),
            nn.Linear(d, 1),
        )

    def forward(
        self,
        h: torch.Tensor,               # [A, d]
        neighbor_mask: torch.Tensor,   # [A, A] 0/1
        trigger: torch.Tensor,         # [A]     0/1
    ) -> torch.Tensor:
        A, d = h.shape
        h_i = h.unsqueeze(1).expand(A, A, d)
        h_j = h.unsqueeze(0).expand(A, A, d)
        h_ij = torch.cat([h_i, h_j], dim=-1)       # [A, A, 2d]

        logits = self.att_mlp(h_ij).squeeze(-1)    # [A, A]

        # 只允许「邻居 & 已触发」的 j 参与
        trigger_j = trigger.view(1, A)             # [1, A]
        comm_mask = neighbor_mask * trigger_j      # [A, A]

        very_neg = torch.finfo(logits.dtype).min
        logits = torch.where(
            comm_mask > 0,
            logits,
            torch.full_like(logits, very_neg),
        )

        alpha = F.softmax(logits, dim=-1)          # [A, A]
        m = alpha @ h                              # [A, d]
        m = torch.where(torch.isnan(m),
                        torch.zeros_like(m), m)
        return m


# ================= Transformer + 决策解码 =================

class PolicyDecoder(nn.Module):
    """
    X_i^t = [h_i^t ; m_i^t ; a_i^t]
    z_i^t = transformerEncoder(X^t)_i
    β_i^t = softmax(MLP(z_i^t))

    注意：这里输出的是未考虑 avail_actions 的分布，真正采样时在
    QDTControllerWithVision.forward_step 里再用 avail_actions 做 mask。
    """

    def __init__(
        self,
        hidden_dim: int,
        n_actions: int,
        act_embed_dim: int = 32,
        n_heads: int = 4,
        n_layers: int = 2,
    ):
        super().__init__()
        self.n_actions = n_actions
        self.act_emb = nn.Embedding(n_actions, act_embed_dim)

        self.in_proj = nn.Linear(hidden_dim + hidden_dim + act_embed_dim,
                                 hidden_dim)

        layer = nn.TransformerEncoderLayer(
            d_model=hidden_dim,
            nhead=n_heads,
            dim_feedforward=4 * hidden_dim,
            batch_first=True,
        )
        self.trans = nn.TransformerEncoder(layer, num_layers=n_layers)

        self.mlp = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, n_actions),
        )

    def forward(
        self,
        h: torch.Tensor,              # [A, d]
        m: torch.Tensor,              # [A, d]
        last_actions: torch.Tensor,   # [A]
    ) -> Dict[str, torch.Tensor]:
        A, d = h.shape
        a_emb = self.act_emb(last_actions)         # [A, E]
        x = torch.cat([h, m, a_emb], dim=-1)       # [A, 2d+E]
        x = self.in_proj(x)                        # [A, d]

        x = x.unsqueeze(0)                         # [1, A, d]
        z = self.trans(x).squeeze(0)              # [A, d]

        logits = self.mlp(z)                      # [A, n_actions]
        beta = F.softmax(logits, dim=-1)
        return dict(z=z, logits=logits, beta=beta)


# ================= QDT + Vision 主体 =================

@dataclass
class QDTVisionConfig:
    vision_cfg: VisionConfig
    n_actions: int
    hidden_dim: Optional[int] = None    # 若为 None，默认用 vision_cfg.embed_dim
    act_embed_dim: int = 32
    n_heads: int = 4
    n_layers: int = 2

    lambda_comm: float = 1e-3
    lambda_qdt: float = 1.0


class QDTControllerWithVision(nn.Module):
    """
    整个控制流程：

    1) 调用 VisionSignalProcessor.process 得到：
          - obs_aug, state_aug
          - per_agent[i]["h_mod"] 作为 h_i^t
          - triggers[i]           作为 Trigger_i^t
    2) 邻居注意力聚合得到 m_i^t
    3) X_i^t = [h_i^t, m_i^t, a_i^t] 送入 transformer 解码出 z_i^t 和 logits_i^t
    4) 用 avail_actions 对 β_i^t 做 mask，只在可用动作集合上采样 a_i^{t+1}
    5) 用 value_head(z_i^t) 预测 QDT 眼中的回报 R_QDT^T
    6) compute_losses(...) 中用 Q-learning 给出的 V_target 作为“老师”计算 L_QDT
    """

    def __init__(self, cfg: QDTVisionConfig):
        super().__init__()
        self.cfg = cfg
        self.device = Device

        # Vision & trigger（完全复用你现有的逻辑）
        self.vision = VisionSignalProcessor(cfg.vision_cfg)

        # 使用 h_mod 的维度作为 hidden_dim
        d = cfg.hidden_dim if cfg.hidden_dim is not None else cfg.vision_cfg.embed_dim
        self.hidden_dim = d

        self.comm = NeighborComm(d)
        self.decoder = PolicyDecoder(
            hidden_dim=d,
            n_actions=cfg.n_actions,
            act_embed_dim=cfg.act_embed_dim,
            n_heads=cfg.n_heads,
            n_layers=cfg.n_layers,
        )

        # QDT 自己的“回报预测 head”，用来产生 R_QDT^T
        self.value_head = nn.Sequential(
            nn.Linear(d, d),
            nn.ReLU(),
            nn.Linear(d, 1),
        )

    # ---------- 单步控制前向 ----------
    def forward_step(
        self,
        env,
        obs_list: List[np.ndarray],
        state: np.ndarray,
        avail_actions: List[np.ndarray],
        neighbor_mask: torch.Tensor,      # [A, A] 0/1
        last_actions: torch.Tensor,       # [A]
        R_hat_scalar: float,
        R_actual_scalar: float,
        actor_for_trigger: nn.Module,     # 用于 Vision 内部计算策略熵的 actor
        greedy: bool = False,
    ) -> Dict[str, Any]:
        """
        返回：
            actions [A]、beta [A, n_actions]、trigger [A]、z [A, d]、
            vision_out 中包含 obs_aug/state_aug/per_agent
        """

        # 1) VisionSignalProcessor：生成视觉编码 + trigger
        vision_out = self.vision.process(
            env=env,
            obs_list=obs_list,
            state=state,
            avail_actions=avail_actions,
            actor=actor_for_trigger,
            Rhat=R_hat_scalar,
            R_actual=R_actual_scalar,
        )
        triggers = vision_out["triggers"]       # list[int] 0/1
        per_agent = vision_out["per_agent"]     # dict[i] -> {..., "h_mod": np.ndarray}

        n_agents = len(obs_list)

        # 2) 构造 h_i^t：优先使用 h_mod，其次 h_vec
        h_list = []
        for i in range(n_agents):
            pa = per_agent[i]
            if pa.get("h_mod") is not None:
                h_i = pa["h_mod"]
            elif pa.get("h_vec") is not None:
                h_i = pa["h_vec"]
            else:
                h_i = np.zeros(self.hidden_dim, dtype=np.float32)
            h_list.append(h_i.astype(np.float32))
        h_np = np.stack(h_list, axis=0)                # [A, d]
        h = torch.as_tensor(h_np, dtype=torch.float32, device=self.device)

        trigger_t = torch.as_tensor(triggers, dtype=torch.float32, device=self.device)
        neighbor_mask = neighbor_mask.to(self.device).float()
        last_actions = last_actions.to(self.device).long()

        # 3) 邻居注意力聚合
        m = self.comm(h, neighbor_mask, trigger_t)     # [A, d]

        # 4) transformer + 决策解码（得到未 mask 的分布）
        dec_out = self.decoder(h, m, last_actions)
        z = dec_out["z"]                               # [A, d]
        beta_raw = dec_out["beta"]                     # [A, n_actions]
        logits = dec_out["logits"]                     # [A, n_actions]

        # 5) 用 avail_actions 做动作 mask，避免选到不可用动作
        avail_np = np.stack(avail_actions, axis=0).astype(np.float32)  # [A, n_actions]
        avail = torch.as_tensor(avail_np, dtype=torch.float32, device=self.device)

        probs = beta_raw * avail                       # [A, n_actions]
        probs_sum = probs.sum(dim=-1, keepdim=True)    # [A, 1]
        probs = probs / (probs_sum + 1e-8)

        # 6) 根据 mask 后的分布采样动作
        if greedy:
            actions = probs.argmax(dim=-1)
        else:
            dist = Categorical(probs=probs)
            actions = dist.sample()

        # 对外返回 mask 后的分布（beta）更方便 debug
        return dict(
            actions=actions,          # a_i^{t+1}
            beta=probs,
            logits=logits,
            trigger=trigger_t,
            z=z,
            vision_out=vision_out,    # 里面有 obs_aug/state_aug/per_agent 给 Q-learning 用
            h=h,
            m=m,
        )

    # ---------- QDT 用 z 预测每个 agent 的回报 ----------
    def predict_returns_from_z(self, z: torch.Tensor) -> torch.Tensor:
        """
        z: [T, A, d]
        return: [T, A]，每个时间-智能体位置上的 R_QDT^T
        """
        v = self.value_head(z)          # [T, A, 1]
        return v.squeeze(-1)           # [T, A]

    # ---------- QDT 的联合损失（L_action 使用 advantage） ----------
    def compute_losses(
        self,
        logits: torch.Tensor,        # [T, A, n_actions]
        actions: torch.Tensor,       # [T, A]
        triggers: torch.Tensor,      # [T, A]
        R_T: torch.Tensor,           # [T, A]  这里约定为 R_QDT^T（QDT 预测）
        R_Q_T: torch.Tensor,         # [T, A]  这里约定为 R_Q-learning^T（老师）
        advantages: torch.Tensor,    # [T, A]  advantage A_t（已经广播到每个 agent）
    ) -> Dict[str, torch.Tensor]:

        cfg = self.cfg
        device = self.device

        logits = logits.to(device)
        actions = actions.to(device).long()
        triggers = triggers.to(device)
        R_T = R_T.to(device)
        R_Q_T = R_Q_T.to(device)

        # advantage：归一化一下再用，防止数值太大太小
        adv = advantages.to(device)
        adv = adv - adv.mean()
        adv_std = adv.std()
        adv = adv / (adv_std + 1e-8)
        adv = adv.detach()          # 只当权重，不反传到 Critic

        T, A, _ = logits.shape

        # 1) L_action：advantage 加权的 policy loss
        log_pi = F.log_softmax(logits, dim=-1)             # [T, A, NA]
        act_index = actions.unsqueeze(-1)                  # [T, A, 1]
        log_pi_a = torch.gather(log_pi, dim=-1, index=act_index).squeeze(-1)  # [T, A]

        # L_action = - E[ A_t * log π(a_t|s_t) ]
        L_action = -(adv * log_pi_a).mean()

        # 2) L_community：触发比例
        L_community = triggers.mean()

        # 3) L_QDT：QDT 预测的回报 vs Q-learning 老师
        L_QDT = ((R_Q_T - R_T) ** 2).mean()

        L_total = L_action + cfg.lambda_comm * L_community + cfg.lambda_qdt * L_QDT
        return dict(
            L_action=L_action,
            L_community=L_community,
            L_QDT=L_QDT,
            L_total=L_total,
        )


# ================= 一个“如何接上 Q-learning”的示意函数 =================

def example_episode_update_with_qdt_and_qlearning(
    controller: QDTControllerWithVision,
    q_module,
    neighbor_mask: torch.Tensor,
    env,
    actor_for_trigger: nn.Module,
):
    """
    用 QDT + Vision + Q-learning 在一条 episode 上跑一遍，并返回各种 loss。

    这里假设 env 是 EnvAdapter：
        reset() -> obs_list, state, avail
        step(actions) -> obs_list2, state2, reward, done, trunc, info, avail2
    """

    # 每个 episode 开头 reset 一次
    obs_list, state, avail_actions = env.reset()
    n_agents = len(obs_list)

    last_actions = torch.zeros(n_agents, dtype=torch.long, device=Device)

    # 轨迹缓存
    logits_traj, actions_traj, trigger_traj = [], [], []
    z_traj = []
    state_aug_traj, reward_traj, done_traj = [], [], []

    done = False
    ep_reward = 0.0
    R_hat_scalar = 0.0
    R_actual_scalar = 0.0

    while not done:
        out = controller.forward_step(
            env=env,
            obs_list=obs_list,
            state=state,
            avail_actions=avail_actions,
            neighbor_mask=neighbor_mask,
            last_actions=last_actions,
            R_hat_scalar=R_hat_scalar,
            R_actual_scalar=R_actual_scalar,
            actor_for_trigger=actor_for_trigger,
            greedy=False,
        )

        actions = out["actions"].cpu().numpy().tolist()
        vision_out = out["vision_out"]

        # 保存 logits / actions / trigger / z
        logits_traj.append(out["logits"].unsqueeze(0))             # [1, A, NA]
        actions_traj.append(out["actions"].unsqueeze(0))           # [1, A]
        trigger_traj.append(out["trigger"].unsqueeze(0))           # [1, A]
        z_traj.append(out["z"].unsqueeze(0))                       # [1, A, d]

        # 保存 state_aug 给 Q-learning 用
        state_aug = torch.as_tensor(
            vision_out["state_aug"],
            dtype=torch.float32,
            device=Device,
        )  # [state_dim]
        state_aug_traj.append(state_aug.unsqueeze(0))              # [1, S]

        # 与环境交互（EnvAdapter 返回 7 个值）
        obs_list2, state2, reward, done_flag, trunc, info, avail2 = env.step(actions)
        done = done_flag or trunc
        ep_reward += float(reward)

        # 这里用「团队 reward」作为 Q-learning 的 reward
        reward_traj.append(torch.tensor(float(reward), device=Device).unsqueeze(0))
        done_traj.append(torch.tensor(float(done), device=Device).unsqueeze(0))

        # 更新 R_actual_scalar（这里用当前累计回报模拟，你也可以换成别的估计）
        R_actual_scalar = ep_reward

        obs_list, state, avail_actions = obs_list2, state2, avail2
        last_actions = out["actions"].detach()

    # ======== Episode 结束：整理 tensor ========
    logits_t = torch.cat(logits_traj, dim=0)        # [T, A, NA]
    actions_t = torch.cat(actions_traj, dim=0)      # [T, A]
    triggers_t = torch.cat(trigger_traj, dim=0)     # [T, A]
    z_t = torch.cat(z_traj, dim=0)                  # [T, A, d]

    state_aug_t = torch.cat(state_aug_traj, dim=0)  # [T, S]
    rewards_t = torch.cat(reward_traj, dim=0).view(-1)  # [T]
    dones_t = torch.cat(done_traj, dim=0).view(-1)      # [T]

    T, A, _ = logits_t.shape

    # 1) 调 Q-learning 更新，得到 V_target（[T]）
    q_loss, V_target = q_module.update(
        state_aug=state_aug_t,
        rewards=rewards_t,
        dones=dones_t,
    )  # V_target: [T]

    # 把 V_target 扩展成 [T, A] 作为 R_Q-learning^T
    R_Q_T = V_target.view(T, 1).expand(T, A)        # [T, A]

    # 2) 用 QDT 自己的 value_head(z) 预测 R_QDT^T
    R_QDT = controller.predict_returns_from_z(z_t)  # [T, A]

    # 3) 计算 advantage：A_t = G_t - V_target
    with torch.no_grad():
        G = q_module.compute_mc_returns(rewards_t, dones_t)   # [T]
        A_vec = G - V_target                                  # [T]
    advantages = A_vec.view(T, 1).expand(T, A)               # [T, A]

    # 4) 计算 QDT 损失（L_action 使用 advantage）
    losses = controller.compute_losses(
        logits=logits_t,
        actions=actions_t,
        triggers=triggers_t,
        R_T=R_QDT,        # QDT 预测
        R_Q_T=R_Q_T,      # Q-learning 老师
        advantages=advantages,
    )

    # QDT 自己的总 loss
    L_qdt_total = losses["L_total"]
    # 联合损失 = QDT + Critic（q_loss 是 detach 的）
    total_loss = L_qdt_total + q_loss

    return dict(
        ep_return=ep_reward,
        q_loss=q_loss,
        L_action=losses["L_action"],
        L_community=losses["L_community"],
        L_QDT=losses["L_QDT"],
        L_qdt_total=L_qdt_total,
        total_loss=total_loss,
    )
