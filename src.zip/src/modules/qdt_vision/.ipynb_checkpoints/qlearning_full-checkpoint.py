# qlearning_full.py
# -*- coding: utf-8 -*-
"""
中心化 Q-learning / value 网络模块

用途：
    - 用 state_aug 序列学习一个 V(s) 作为 Critic
    - 把更新后的 V(s) 当成 R_Q-learning^T，供 QDT 模块模仿
"""

from dataclasses import dataclass
from typing import Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F


@dataclass
class QLConfig:
    state_dim: int
    hidden_dim: int = 256
    lr: float = 3e-4
    gamma: float = 0.99
    device: str = "cuda" if torch.cuda.is_available() else "cpu"


class CentralValueNet(nn.Module):
    """
    中心化价值网络：输入增强后的全局状态 state_aug，输出标量 V(s)
    """

    def __init__(self, cfg: QLConfig):
        super().__init__()
        self.cfg = cfg
        self.net = nn.Sequential(
            nn.Linear(cfg.state_dim, cfg.hidden_dim),
            nn.ReLU(),
            nn.Linear(cfg.hidden_dim, cfg.hidden_dim),
            nn.ReLU(),
            nn.Linear(cfg.hidden_dim, 1),
        )

    def forward(self, s: torch.Tensor) -> torch.Tensor:
        """
        s: [T, state_dim]
        return: [T] 标量 V(s)
        """
        return self.net(s).squeeze(-1)


class QLearningModule:
    """
    对外接口：
        - compute_mc_returns(rewards, dones) -> G_t（MC 回报）
        - update(state_aug, rewards, dones) -> (q_loss, V_target)

    其中：
        q_loss   : value 网络自己的 MSE 损失（已 detach，用于监控）
        V_target : [T]，更新之后的 V(s_t)，作为 R_Q-learning^T 提供给 QDT
    """

    def __init__(self, cfg: QLConfig):
        self.cfg = cfg
        self.device = torch.device(cfg.device)
        self.vnet = CentralValueNet(cfg).to(self.device)
        self.optim = torch.optim.Adam(self.vnet.parameters(), lr=cfg.lr)

    @torch.no_grad()
    def compute_mc_returns(
        self,
        rewards: torch.Tensor,
        dones: torch.Tensor,
    ) -> torch.Tensor:
        """
        简单的 MC 回报（按 episode 反向累计；done 处截断）
        rewards: [T]
        dones:   [T]  0/1，1 表示该步结束一个 episode
        """
        gamma = self.cfg.gamma
        T = rewards.shape[0]
        G = torch.zeros_like(rewards)
        running = 0.0
        for t in reversed(range(T)):
            running = rewards[t] + gamma * running * (1.0 - dones[t])
            G[t] = running
        return G

    def update(
        self,
        state_aug: torch.Tensor,   # [T, state_dim]
        rewards: torch.Tensor,     # [T]
        dones: torch.Tensor,       # [T]
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        用一条（或多条拼在一起的）episode 更新一次 value 网络。

        返回：
            q_loss   : 标量，value 网络的 MSE 损失（已 detach）
            V_target : [T]，更新后的 V(s_t)，作为 R_Q-learning^T 给 QDT 使用
        """
        device = self.device
        state_aug = state_aug.to(device)
        rewards = rewards.to(device)
        dones = dones.to(device)

        # 1) 计算 MC 回报作为目标
        G = self.compute_mc_returns(rewards, dones)  # [T]

        # 2) 预测 V(s_t)
        V_pred = self.vnet(state_aug)                # [T]

        # 3) MSE 损失（对 value 网络自己反向）
        loss = F.mse_loss(V_pred, G.detach())

        self.optim.zero_grad()
        loss.backward()
        nn.utils.clip_grad_norm_(self.vnet.parameters(), 10.0)
        self.optim.step()

        # 4) 更新后的 V(s)（不带梯度），作为给 QDT 的“老师”
        with torch.no_grad():
            V_target = self.vnet(state_aug)          # [T]

        return loss.detach(), V_target.detach()
