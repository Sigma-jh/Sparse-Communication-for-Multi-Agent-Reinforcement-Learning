from .patched_vision_signal import VisionConfig, VisionSignalProcessor
from .qdt_with_vision import QDTVisionConfig, QDTControllerWithVision
from .qlearning_full import QLearningModule

# 兼容不同命名：QLConfig / QConfig / 没有 config
try:
    from .qlearning_full import QLConfig
except Exception:
    try:
        from .qlearning_full import QConfig as QLConfig
    except Exception:
        from dataclasses import dataclass

        @dataclass
        class QLConfig:
            state_dim: int
            lr: float = 3e-4
            gamma: float = 0.99
