
# patched_vision_signal.py
from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any, List, Optional, Tuple
import numpy as np
import torch
import torch.nn as nn

@dataclass
class VisionConfig:
    use_cnn: bool = False
    img_size: Tuple[int, int] = (30, 30)
    img_channels: int = 1
    cnn_embed_dim: int = 128
    cnn_to_obs: bool = False
    cnn_to_state: bool = False

    view_size: float = 15.0
    max_friend: int = 7
    max_enemy: int = 16
    append_pos_to_obs: bool = False
    append_pos_to_state: bool = False

    embed_dim: int = 128
    use_modalign: bool = False
    append_mod_to_obs: bool = False
    append_mod_to_state: bool = False

    add_trigger_bit: bool = False
    tau_H: float = 1.2
    use_deltaR: bool = False
    tau_R: float = 0.5
    trigger_to: str = "obs"

    debug: bool = False
    debug_max_agents: int = 3

class CNNEncoder(nn.Module):
    def __init__(self, in_channels: int, out_dim: int):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels, 32, 3, 2, 1), nn.ReLU(),
            nn.Conv2d(32, 64, 3, 2, 1), nn.ReLU(),
            nn.Conv2d(64, 96, 3, 2, 1), nn.ReLU(),
        )
        self.head = nn.Sequential(nn.Flatten(), nn.Linear(96*4*4, out_dim), nn.Tanh())
    def forward(self, x): return self.head(self.conv(x))

def as1d(x)->np.ndarray:
    return np.asarray(x, dtype=np.float32).reshape(-1)
def align_len(x: np.ndarray, target: int)->np.ndarray:
    arr = as1d(x)
    if target is None: return arr
    if arr.size == target: return arr
    if arr.size > target: return arr[:target]
    return np.concatenate([arr, np.zeros(target - arr.size, dtype=np.float32)], axis=0)

def first_linear_io(actor):
    try:
        for m in actor.modules():
            if isinstance(m, nn.Linear):
                return m.in_features, m.out_features
    except Exception:
        pass
    return None, None

class VectorStateEncoder:
    def __init__(self, in_dim: int, hidden_dim: int = 128):
        self.in_dim = in_dim; self.hidden_dim = hidden_dim
    def encode(self, x: np.ndarray) -> np.ndarray:
        y = np.tanh(as1d(x))
        if y.shape[0] < self.hidden_dim: y = np.pad(y, (0, self.hidden_dim - y.shape[0]))
        return y[:self.hidden_dim]

class TargetReturnEmbedder:
    def __init__(self, hidden_dim: int = 128): self.hidden_dim = hidden_dim
    def encode(self, Rhat: float) -> np.ndarray:
        y = np.tanh(np.array([Rhat], dtype=np.float32))
        return np.pad(y, (0, self.hidden_dim-1))

class ModalityAlignmentProjector:
    def __init__(self, hidden_dim: int = 128, seed: int = 42):
        rng = np.random.default_rng(seed)
        self.W = rng.standard_normal((hidden_dim, hidden_dim*2)).astype(np.float32)
    def project(self, h_vec: np.ndarray, h_R: np.ndarray) -> np.ndarray:
        x = np.concatenate([h_vec, h_R], axis=0).astype(np.float32)[: self.W.shape[1]]
        y = self.W @ x
        mu, sigma = y.mean(), y.std() + 1e-6
        return (y - mu) / sigma

def build_position_state(env, agent_id: int, view_size: float,
                         max_friend: int, max_enemy: int) -> np.ndarray:
    try:
        a = env.get_unit_by_id(agent_id)
    except Exception:
        return np.zeros(3 + max_friend*3 + max_enemy*3, dtype=np.float32)
    if getattr(a, "health", 0) <= 0:
        return np.zeros(3 + max_friend*3 + max_enemy*3, dtype=np.float32)

    cx, cy = float(a.pos.x), float(a.pos.y)
    self_block = np.array([cx, cy, a.health/100.0], dtype=np.float32)

    friends = []
    n_agents = getattr(env, "n_agents", 0)
    for aid in range(n_agents):
        if aid == agent_id: continue
        try:
            u = env.get_unit_by_id(aid)
        except Exception:
            continue
        if getattr(u, "health", 0) <= 0: continue
        friends.append([(u.pos.x - cx)/max(1.0, view_size),
                        (u.pos.y - cy)/max(1.0, view_size),
                        u.health/100.0])
    while len(friends) < max_friend: friends.append([0.0,0.0,0.0])
    friends = friends[:max_friend]

    enemies = []
    enemy_ids = []
    if hasattr(env, "enemies"): enemy_ids = list(env.enemies.keys())
    elif hasattr(env, "enemy_units"): enemy_ids = list(env.enemy_units.keys())
    for eid in enemy_ids:
        try:
            u = env.get_unit_by_id(eid)
        except Exception:
            continue
        if getattr(u, "health", 0) <= 0: continue
        enemies.append([(u.pos.x - cx)/max(1.0, view_size),
                        (u.pos.y - cy)/max(1.0, view_size),
                        u.health/100.0])
    while len(enemies) < max_enemy: enemies.append([0.0,0.0,0.0])
    enemies = enemies[:max_enemy]

    return np.concatenate([self_block,
                           np.array(friends, dtype=np.float32).ravel(),
                           np.array(enemies, dtype=np.float32).ravel()]).astype(np.float32)

class VisionSignalProcessor:
    def __init__(self, cfg: VisionConfig):
        self.cfg = cfg
        self.cnn = CNNEncoder(cfg.img_channels, cfg.cnn_embed_dim).eval() if cfg.use_cnn else None
        in_dim = 3 + cfg.max_friend*3 + cfg.max_enemy*3
        self.vec_enc = VectorStateEncoder(in_dim, cfg.embed_dim)
        self.R_enc   = TargetReturnEmbedder(cfg.embed_dim)
        self.proj    = ModalityAlignmentProjector(cfg.embed_dim)

    @torch.no_grad()
    def _policy_probs(self, actor, obs_i: np.ndarray, mask_i: np.ndarray) -> np.ndarray:
        in_dim, _ = first_linear_io(actor)
        x = align_len(obs_i, in_dim if in_dim is not None else obs_i.shape[-1])
        device = next(actor.parameters()).device
        obs_t = torch.as_tensor(x, dtype=torch.float32, device=device).unsqueeze(0)
        m = as1d(mask_i)
        logits = actor(obs_t)
        L = int(logits.shape[-1])
        if m.size < L: m = np.concatenate([m, np.ones(L-m.size, dtype=np.float32)])
        elif m.size > L: m = m[:L]
        mask_t = torch.as_tensor(m, dtype=torch.float32, device=device).unsqueeze(0)
        very_neg = torch.finfo(logits.dtype).min/2
        logits_masked = torch.where(mask_t>0, logits, very_neg)
        dist = torch.distributions.Categorical(logits=logits_masked)
        p = dist.probs.squeeze(0).detach().cpu().numpy()
        return p / max(1e-8, p.sum())

    def _extract_image_from_obs(self, obs_i: np.ndarray) -> Optional[np.ndarray]:
        H, W = self.cfg.img_size; C = self.cfg.img_channels
        flat = as1d(obs_i)
        if obs_i.ndim == 3 and (obs_i.shape[0] in (1,3)) and obs_i.shape[1]==H and obs_i.shape[2]==W:
            return obs_i.astype(np.float32)
        if obs_i.ndim == 2 and obs_i.shape == (H, W):
            return obs_i[np.newaxis, ...].astype(np.float32)
        if flat.size == C*H*W:
            return flat.reshape(C, H, W).astype(np.float32)
        if flat.size == H*W and C == 1:
            return flat.reshape(1, H, W).astype(np.float32)
        return None

    def process(self, env, obs_list: List[np.ndarray], state: np.ndarray,
                avail_actions: List[np.ndarray], actor=None,
                Rhat: Optional[float]=None, R_actual: Optional[float]=None) -> Dict[str, Any]:
        cfg = self.cfg; n_agents = len(obs_list)
        obs_aug = [as1d(o) for o in obs_list]; state_aug = as1d(state)
        base_len = max([o.size for o in obs_aug]) if n_agents>0 else 0
        triggers = [0]*n_agents; per_agent: Dict[int, Dict[str, Any]] = {}
        Rhat = float(Rhat if Rhat is not None else 0.0); R_actual = float(R_actual if R_actual is not None else 0.0)

        vec_dim = 3 + cfg.max_friend*3 + cfg.max_enemy*3
        O_new = base_len                 + (cfg.cnn_to_obs * cfg.cnn_embed_dim)                 + (cfg.append_pos_to_obs * vec_dim)                 + ((cfg.use_modalign and cfg.append_mod_to_obs) * cfg.embed_dim)                 + ((cfg.add_trigger_bit and cfg.trigger_to in ("obs","both")) * 1)
        O_new = int(O_new)

        cnn_embeds = []
        for i in range(n_agents):
            parts = [align_len(obs_aug[i], base_len)]
            cnn_feat=None; vec=None; h_vec=None; h_mod=None

            if cfg.use_cnn and self.cnn is not None:
                img = self._extract_image_from_obs(obs_aug[i])
                if img is not None:
                    x = torch.as_tensor(img/255.0 if img.max()>1.0 else img, dtype=torch.float32).unsqueeze(0)
                    with torch.no_grad(): cnn_feat = self.cnn(x).squeeze(0).cpu().numpy().astype(np.float32)
                if cfg.cnn_to_obs:
                    if cnn_feat is None:
                        cnn_feat = np.zeros(cfg.cnn_embed_dim, dtype=np.float32)
                    parts.append(cnn_feat)
                if cnn_feat is not None:
                    cnn_embeds.append(cnn_feat)

            if cfg.append_pos_to_obs or cfg.append_pos_to_state or cfg.use_modalign:
                vec = build_position_state(env, i, cfg.view_size, cfg.max_friend, cfg.max_enemy)
                if cfg.append_pos_to_obs:
                    parts.append(vec)
                if cfg.use_modalign:
                    h_vec = self.vec_enc.encode(vec)

            if cfg.use_modalign:
                if h_vec is None and cnn_feat is not None:
                    h_vec = align_len(cnn_feat, cfg.embed_dim)
                h_R = self.R_enc.encode(Rhat)
                h_mod = self.proj.project(h_vec, h_R) if h_vec is not None else None
                if cfg.append_mod_to_obs:
                    parts.append(h_mod if h_mod is not None else np.zeros(cfg.embed_dim, dtype=np.float32))

            trig = 0
            if cfg.add_trigger_bit and actor is not None:
                p = self._policy_probs(actor, obs_aug[i], avail_actions[i])
                H = float(-(np.clip(p,1e-8,1.0)*np.log(np.clip(p,1e-8,1.0))).sum())
                cond_H = (H > cfg.tau_H); cond_R = (abs(Rhat - R_actual) > cfg.tau_R) if cfg.use_deltaR else False
                trig = int(cond_H or cond_R); triggers[i]=trig
            if cfg.add_trigger_bit and cfg.trigger_to in ("obs","both"):
                parts.append(np.array([float(trig)], dtype=np.float32))

            oi = np.concatenate(parts, axis=-1)
            obs_aug[i] = align_len(oi, O_new)

            per_agent[i] = dict(cnn_feat=cnn_feat, vector_state=vec, h_vec=h_vec, h_mod=h_mod)

        s_parts = [state_aug]
        if cfg.cnn_to_state:
            if cnn_embeds:
                pooled = np.mean(np.stack(cnn_embeds, 0), 0).astype(np.float32)
            else:
                pooled = np.zeros(cfg.cnn_embed_dim, dtype=np.float32)
            s_parts.append(pooled)
        if cfg.append_pos_to_state:
            vecs = [per_agent[i]["vector_state"] for i in range(n_agents) if per_agent[i]["vector_state"] is not None]
            if vecs:
                s_parts.append(np.mean(np.stack(vecs,0),0).astype(np.float32))
            else:
                s_parts.append(np.zeros(vec_dim, dtype=np.float32))
        if cfg.use_modalign and cfg.append_mod_to_state:
            mods = [per_agent[i]["h_mod"] for i in range(n_agents) if per_agent[i]["h_mod"] is not None]
            if mods:
                s_parts.append(np.mean(np.stack(mods,0),0).astype(np.float32))
            else:
                s_parts.append(np.zeros(cfg.embed_dim, dtype=np.float32))
        if cfg.add_trigger_bit and cfg.trigger_to in ("state","both"):
            s_parts.append(np.array(triggers, dtype=np.float32))
        state_aug = np.concatenate(s_parts, -1).astype(np.float32)

        return dict(obs_aug=obs_aug, state_aug=state_aug, triggers=triggers, per_agent=per_agent)
