import torch as th
import torch.nn as nn
import torch.nn.functional as F

class ObsEncoder(nn.Module):
    """
    输入: obs [bs, n_agents, obs_dim]
    输出: h   [bs, n_agents, h_dim]
    """
    def __init__(self, obs_dim: int, h_dim: int, hidden: int = 128):
        super().__init__()
        self.fc1 = nn.Linear(obs_dim, hidden)
        self.fc2 = nn.Linear(hidden, h_dim)

    def forward(self, obs: th.Tensor) -> th.Tensor:
        x = F.relu(self.fc1(obs))
        return self.fc2(x)
