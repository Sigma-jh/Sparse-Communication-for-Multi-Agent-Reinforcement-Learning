# import torch as th
# import torch.nn as nn
# import torch.nn.functional as F


# class TriggerNet(nn.Module):
#     """
#     Produce per-agent trigger in [0,1] (or hard 0/1 with STE) from agent hidden features.
#     Input:  h  [bs, n_agents, h_dim]
#     Output: trig [bs, n_agents, 1]
#     """
#     def __init__(self, h_dim: int, hidden_dim: int = 64, hard: bool = True, tau: float = 1.0):
#         super().__init__()
#         self.h_dim = h_dim
#         self.hidden_dim = hidden_dim
#         self.hard = hard
#         self.tau = tau

#         self.net = nn.Sequential(
#             nn.Linear(h_dim, hidden_dim),
#             nn.ReLU(),
#             nn.Linear(hidden_dim, 1)
#         )

#     def forward(self, h: th.Tensor, test_mode: bool = False) -> th.Tensor:
#         # h: [bs, A, h_dim]
#         logits = self.net(h) / max(self.tau, 1e-6)  # [bs, A, 1]
#         prob = th.sigmoid(logits)

#         if (not self.hard) or test_mode:
#             return prob

#         # Hard trigger with Straight-Through Estimator
#         hard = (prob > 0.2).float()
#         trig = hard.detach() - prob.detach() + prob
#         return trig
import torch as th
import torch.nn as nn
import torch.nn.functional as F


class AllyGridEncoder(nn.Module):
    """
    Encode ally occupancy grid (1xHxW) -> vector.
    Use AdaptiveAvgPool so it works even if H/W not exactly 31.
    """
    def __init__(self, out_dim: int = 64):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(1, 16, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.Conv2d(16, 32, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.AdaptiveAvgPool2d((1, 1)),
        )
        self.fc = nn.Linear(32, out_dim)

    def forward(self, grid: th.Tensor) -> th.Tensor:
        # grid: [B, 1, H, W]
        x = self.conv(grid).view(grid.size(0), -1)  # [B, 32]
        return self.fc(x)                           # [B, out_dim]


class TriggerNet(nn.Module):
    """
    Produce per-agent trigger in [0,1] (or hard 0/1 with STE) from agent hidden features
    and (optionally) local ally grid around each agent.

    Inputs:
      h:         [bs, n_agents, h_dim]
      ally_grid: [bs, n_agents, 1, H, W]  (optional)

    Output:
      trig:      [bs, n_agents, 1]
    """
    def __init__(
        self,
        h_dim: int,
        hidden_dim: int = 64,
        hard: bool = True,
        tau: float = 1.0,
        use_ally_grid: bool = True,
        grid_feat_dim: int = 64,
    ):
        super().__init__()
        self.h_dim = int(h_dim)
        self.hidden_dim = int(hidden_dim)
        self.hard = bool(hard)
        self.tau = float(tau)

        self.use_ally_grid = bool(use_ally_grid)
        self.grid_feat_dim = int(grid_feat_dim)

        if self.use_ally_grid:
            self.grid_enc = AllyGridEncoder(out_dim=self.grid_feat_dim)
            in_dim = self.h_dim + self.grid_feat_dim
        else:
            self.grid_enc = None
            in_dim = self.h_dim

        self.net = nn.Sequential(
            nn.Linear(in_dim, self.hidden_dim),
            nn.ReLU(),
            nn.Linear(self.hidden_dim, 1)
        )

    def forward(self, h: th.Tensor, ally_grid: th.Tensor = None, test_mode: bool = False) -> th.Tensor:
        # h: [bs, A, h_dim]
        if self.use_ally_grid and (ally_grid is not None):
            # ally_grid: [bs, A, 1, H, W] -> flatten agents as batch
            bs, A, _, H, W = ally_grid.shape
            g = ally_grid.reshape(bs * A, 1, H, W)
            gfeat = self.grid_enc(g).reshape(bs, A, self.grid_feat_dim)  # [bs, A, grid_feat_dim]
            x = th.cat([h, gfeat], dim=-1)
        else:
            x = h

        logits = self.net(x) / max(self.tau, 1e-6)  # [bs, A, 1]
        prob = th.sigmoid(logits)

        if (not self.hard) or test_mode:
            return prob

        # Hard trigger with Straight-Through Estimator
        hard = (prob > 0.2).float()  #原来是0.2
        trig = hard.detach() - prob.detach() + prob
        return trig
