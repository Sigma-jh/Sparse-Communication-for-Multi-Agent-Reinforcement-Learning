import torch as th
import torch.nn as nn
import torch.nn.functional as F

class TriggerNet(nn.Module):
    """
    输入:  h  [bs, n_agents, h_dim]
    输出:  triggers [bs, n_agents, 1]  (0/1 采样，训练可用 straight-through)
    """
    def __init__(self, h_dim: int, hidden_dim: int = 64, hard: bool = True):
        super().__init__()
        self.hard = hard
        self.fc1 = nn.Linear(h_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, 1)

    def forward(self, h: th.Tensor, test_mode: bool = False) -> th.Tensor:
        x = F.relu(self.fc1(h))
        logits = self.fc2(x)  # [bs, n_agents, 1]
        prob = th.sigmoid(logits)

        if test_mode:
            # 测试：确定性（>0.5 就触发）
            return (prob > 0.5).float()

        if self.hard:
            # 训练：Bernoulli 采样 + straight-through
            sample = th.bernoulli(prob)
            return sample + (prob - prob.detach())
        else:
            # 训练：软触发（如果你想更稳定）
            return prob
