import torch as th
import torch.nn as nn
import torch.nn.functional as F

class NeighborComm(nn.Module):
    """
    输入:
      h:         [bs, n_agents, h_dim]
      neighbor:  [n_agents, n_agents] (0/1)  i->j 是否可通信（邻居）
      triggers:  [bs, n_agents, 1]     每个 agent 是否触发（作为发送 gate）
    输出:
      m:         [bs, n_agents, h_dim] 聚合消息
    """
    def __init__(self, h_dim: int, attn_hidden: int = 64):
        super().__init__()
        self.attn = nn.Sequential(
            nn.Linear(2 * h_dim, attn_hidden),
            nn.ReLU(),
            nn.Linear(attn_hidden, 1)
        )

    def forward(self, h: th.Tensor, neighbor_mask: th.Tensor, triggers: th.Tensor) -> th.Tensor:
        bs, A, D = h.shape
        device = h.device

        # neighbor_mask: [A, A] -> [bs, A, A]
        nmask = neighbor_mask.to(device=device, dtype=th.float32).unsqueeze(0).expand(bs, -1, -1)

        # trigger gate：只允许“发送者 j”触发才参与
        # triggers: [bs, A, 1] -> [bs, 1, A]
        send_gate = triggers.squeeze(-1).unsqueeze(1)  # [bs, 1, A]

        comm_mask = nmask * send_gate  # [bs, A, A]  i<-j 是否接收 j

        # pair features
        hi = h.unsqueeze(2).expand(bs, A, A, D)  # [bs, A, A, D]
        hj = h.unsqueeze(1).expand(bs, A, A, D)  # [bs, A, A, D]
        pair = th.cat([hi, hj], dim=-1)          # [bs, A, A, 2D]

        logits = self.attn(pair).squeeze(-1)     # [bs, A, A]
        # mask 掉不可通信
        logits = logits.masked_fill(comm_mask <= 0, -1e9)

        alpha = F.softmax(logits, dim=-1)        # [bs, A, A]
        m = th.bmm(alpha, h)                     # [bs, A, D]
        return m
